#include "server.h"
#include "csapp.h"
#include "transaction.h"
#include "server.h"
#include <sys/time.h>
#include <time.h>
#include "data.h"
#include "protocol.h"
#include "debug.h"
#include "store.h"

CLIENT_REGISTRY *client_registry;
/*
 * Thread function for the thread that handles client requests.
 *
 * @param  Pointer to a variable that holds the file descriptor for
 * the client connection.  This pointer must be freed once the file
 * descriptor has been retrieved.
 */
void send_reply_pkt(int fd, int status){
    struct timespec time;
    XACTO_PACKET *reply_pkt=Malloc(sizeof(XACTO_PACKET));
    timespec_get(&time,TIME_UTC);
    //gettimeofday(&time,NULL);
    reply_pkt->type=XACTO_REPLY_PKT;
    reply_pkt->size=0;
    reply_pkt->status=status;
    reply_pkt->null=0;
    reply_pkt->timestamp_sec=time.tv_sec;
    reply_pkt->timestamp_nsec=time.tv_nsec;
    proto_send_packet(fd,reply_pkt,NULL);
    Free(reply_pkt);
}
void send_data_pkt(int fd, int status, BLOB* data){
    struct timespec time;
    XACTO_PACKET *data_pkt=Malloc(sizeof(XACTO_PACKET));
    timespec_get(&time,TIME_UTC);
    data_pkt->type=XACTO_DATA_PKT;
    data_pkt->status=status;
    data_pkt->timestamp_sec=time.tv_sec;
    data_pkt->timestamp_nsec=time.tv_nsec;
    if(data==NULL){
        data_pkt->size=0;
        data_pkt->null=1;
        proto_send_packet(fd,data_pkt,NULL);
    }
    else{
        data_pkt->size=strlen(data->content);
        data_pkt->null=0;
        proto_send_packet(fd,data_pkt,data->content);

    }
    Free(data_pkt);

}

void *xacto_client_service(void *arg){
    int fd=*((int*)arg);
    TRANSACTION *trans;
    Pthread_detach(Pthread_self());
    Free(arg);
    debug("[%d] Starting client service",fd);
    creg_register(client_registry,fd);
    trans=trans_create();
    while(1){
        XACTO_PACKET *pkt=Malloc(sizeof(XACTO_PACKET));
        XACTO_PACKET *data_pkt=Malloc(sizeof(XACTO_PACKET));
        XACTO_PACKET *key_pkt=Malloc(sizeof(XACTO_PACKET));
        BLOB** blob=Malloc(sizeof(BLOB*));
        void **datap=Malloc(sizeof(void*));
        void **value=Malloc(sizeof(void*));
        void **key=Malloc(sizeof(void*));
        if(proto_recv_packet(fd,pkt,datap)<0){
            Free(datap);
            Free(value);
            Free(key);
            Free(pkt);
            Free(blob);
            Free(data_pkt);
            Free(key_pkt);
            debug("[%d]Ending client service",fd);
            if(trans->status==TRANS_ABORTED)
                trans_abort(trans);//test
            creg_unregister(client_registry,fd);
            break;
        }
        if(pkt->type==XACTO_PUT_PKT){
            if(proto_recv_packet(fd,key_pkt,key)<0){
                trans_abort(trans);
                Free(datap);
                Free(value);
                Free(key);
                Free(pkt);
                Free(blob);
                Free(data_pkt);
                Free(key_pkt);
                break;
            }
            if(proto_recv_packet(fd,data_pkt,value)<0){
                trans_abort(trans);
                Free(datap);
                Free(value);
                Free(key);
                Free(pkt);
                Free(blob);
                Free(data_pkt);
                Free(key_pkt);
                break;
            }
            debug("[%d]PUT packet received",fd);//test
            debug("[%d]Recieved key, size %d",fd,key_pkt->size);//test
            debug("[%d]Recieved value, size %d",fd,data_pkt->size);
            BLOB* key_blob=blob_create((char*)*key, key_pkt->size);
            KEY *n_key=key_create(key_blob);
            //debug("key hash->%d",n_key->hash);//test
            BLOB *value_blob=blob_create((char*)*value, data_pkt->size);
            trans->status=store_put(trans, n_key, value_blob);
            store_show();//test
            trans_show_all();//test
        }
        else if(pkt->type==XACTO_GET_PKT){
            if(proto_recv_packet(fd,key_pkt,key)<0){
                trans->status=trans_abort(trans);
            }
            debug("[%d]GET packet received",fd);
            debug("[%d]Recieved key, size %d",fd,key_pkt->size);
            BLOB* key_blob=blob_create((char*)*key, key_pkt->size);
            KEY *n_key=key_create(key_blob);
            trans->status=store_get(trans, n_key, blob);
            store_show();//test
            trans_show_all();//test
            //store_get(trans, n_key, blob);
        }
        else if(pkt->type==XACTO_COMMIT_PKT){
            debug("[%d]COMMIT packet received",fd);//test
            trans->status=trans_commit(trans);
            store_show();//test
            trans_show_all();//test

        }
        send_reply_pkt(fd,trans->status);
        if(pkt->type==XACTO_GET_PKT)
            send_data_pkt(fd,trans->status,*blob);//test

        Free(datap);
        Free(value);
        Free(key);
        Free(pkt);
        Free(blob);
        Free(data_pkt);
        Free(key_pkt);

    }
    return NULL;

}
