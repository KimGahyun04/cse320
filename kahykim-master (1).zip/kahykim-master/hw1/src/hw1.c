#include <stdlib.h>

#include "debug.h"
#include "hw1.h"


#ifdef _STRING_H
#error "Do not #include <string.h>. You will get a ZERO."
#endif

#ifdef _STRINGS_H
#error "Do not #include <strings.h>. You will get a ZERO."
#endif

#ifdef _CTYPE_H
#error "Do not #include <ctype.h>. You will get a ZERO."
#endif

#define SUCCESS_FLAG "-h\0"
#define SPEEDUP_FLAG "-u\0"
#define SLOWDOWN_FLAG "-d\0"
#define CRYPT_FLAG "-c\0"
#define FACTOR_OPTION "-f\0"
#define PRESERVE_OPTION "-p\0"
#define KEY_OPTION "-k\0"
#define MAX_KEYNUM 9

/*
*define the flag and optional flag using a macro
*to make the code readable
*/


/*
 * You may modify this file and/or move the functions contained here
 * to other source files (except for main.c) as you wish.
 *
 * IMPORTANT: You MAY NOT use any array brackets (i.e. [ and ]) and
 * you MAY NOT declare any arrays or allocate any storage with malloc().
 * The purpose of this restriction is to force you to use pointers.
 * Variables to hold the content of three frames of audio data and
 * two annotation fields have been pre-declared for you in const.h.
 * You must use those variables, rather than declaring your own.
 * IF YOU VIOLATE THIS RESTRICTION, YOU WILL GET A ZERO!
 *
 * IMPORTANT: You MAY NOT use floating point arithmetic or declare
 * any "float" or "double" variables.  IF YOU VIOLATE THIS RESTRICTION,
 * YOU WILL GET A ZERO!
 */

/**
 * @brief Validates command line arguments passed to the program.
 * @details This function will validate all the arguments passed to the
 * program, returning 1 if validation succeeds and 0 if validation fails.
 * Upon successful return, the selected program options will be set in the
 * global variables "global_options", where they will be accessible
 * elsewhere in the program.
 *
 * @param argc The number of arguments passed to the program from the CLI.
 * @param argv The argument strings passed to the program from the CLI.
 * @return 1 if validation succeeds and 0 if validation fails.
 * Refer to the homework document for the effects of this function on
 * global variables.
 * @modifies global variable "global_options" to contain a bitmap representing
 * the selected options.
 */


int checkFirstFlag(char *string1);
int checkOptionFlag(char *string1);
int checkHex(char *string1);
int checkOptionOrder(int flag_num, char *option, char *option_details);


int validargs(int argc, char **argv)
{
    char *first_flag;
    char *first_optional_flag;
    char *second_optional_flag;
    char *optional_details;
    int first_flag_num, first_optional_flag_num, second_optional_flag_num;


    if(argc<2)
        return 0;

    else{
        first_flag=*(argv+1);
        first_flag_num=checkFirstFlag(first_flag);

        if(first_flag_num==1){
            return 1;
        }


        if(argc==2){
            if(first_flag_num > 0)
                return 1;
            else{
                global_options=0;
                return 0;
            }
        }

        else if(argc==3){
            first_optional_flag=*(argv+2);
            first_optional_flag_num=checkOptionFlag(first_optional_flag);

            if(first_flag_num > 0){
                if(first_optional_flag_num<0)
                    return 1;
                else{
                    global_options=0;
                    return 0;
                }
            }
            else{
                global_options=0;
                return 0;
            }
        }
        else if(argc == 4){
             first_optional_flag=*(argv+2);
             optional_details=*(argv+3);
             first_optional_flag_num=checkOptionFlag(first_optional_flag);

             if(first_flag_num > 0){

                if(checkOptionOrder(first_flag_num,first_optional_flag,optional_details))
                     return 1;
                else{
                    global_options=0;
                    return 0;
                }

             }
             else{
                global_options=0;
                 return 0;
             }


        }
        else if(argc ==5){
            first_optional_flag=*(argv+2);
            first_optional_flag_num=checkOptionFlag(first_optional_flag);

             if(first_flag_num > 0){
                 if(first_optional_flag_num < 0) {
                    second_optional_flag=*(argv+3);
                    optional_details=*(argv+4);
                    if(checkOptionOrder(first_flag_num,second_optional_flag,optional_details))
                        return 1;
                    else{
                        global_options=0;
                        return 0;
                    }
                 }
                 else if(first_optional_flag_num > 0){
                    optional_details=*(argv+3);
                    second_optional_flag=*(argv+4);
                    second_optional_flag_num=checkOptionFlag(second_optional_flag);

                    if(checkOptionOrder(first_flag_num,first_optional_flag,optional_details)){
                        if(second_optional_flag_num < 0)
                            return 1;
                        else{
                            global_options=0;
                            return 0;
                        }
                    }
                    else{
                        global_options=0;
                        return 0;
                    }
                 }
                 else{
                    global_options=0;
                    return 0;
                 }

             }
             else{
                global_options=0;
                 return 0;
             }

        }
        else{
            global_options=0;
            return 0;
        }

    }

}
/*
*checkFirstFlag function checks the first argument is resonable.
*it returns the intger values.
*(SUCCESS_FLAG =1, SPEEDUP_FLAG =2 ,SLOWDOWN_FLAG =3, CRYPT_FLAG =4)
*and if it is incorrect, than it returns the 0;
*/

int checkFirstFlag(char *string1){
    int flag;
    global_options=0x1L;

    if(!stringCompare(string1,SUCCESS_FLAG)){
        global_options = global_options << 63;
        return 1;
    }
    else if(!stringCompare(string1, SPEEDUP_FLAG)){
        global_options = global_options << 62;
        return 2;
    }
    else if(!stringCompare(string1,SLOWDOWN_FLAG)){
        global_options = global_options << 61;
        return 3;
    }
    else if(!stringCompare(string1,CRYPT_FLAG)){
        global_options = global_options << 60;
        return 4;
    }
    else
        return 0;


}
/*
*check optional flag.
* it returns the intger values.
*(PRESERVE_OPTION =-1, FACTOR_OPTION =1 ,KEY_OPTION =2)
*and if it is incorrect, than it returns the 0;
*/

int checkOptionFlag(char *string1){
    if(!stringCompare(string1,PRESERVE_OPTION)){
        global_options = global_options|(0x1l << 59);
        return -1;
    }
    else if(!stringCompare(string1,FACTOR_OPTION)){
        return 1;
    }
    else if(!stringCompare(string1,KEY_OPTION)){
        return 2;
    }
    else
        return 0;

}
/*
*check if the string is the Hexadecimial that has specific range(0~9,A~F,a~g)
* and it has to be under 9 digits
* if it satisfied the conditon it returns 1 if not it returns 0
*/

int checkHex(char *string1){
    int i;
    int Hex;
    for(i=0;*(string1+i)!='\0';i++){
        if(('0' <=*(string1+i) && *(string1+i) <='9') || ('a' <=*(string1+i) && *(string1+i) <='f') || ('A' <=*(string1+i) && *(string1+i) <='F')){

        }
        else{
            Hex=-1;
            break;
        }
    }
    if((i<MAX_KEYNUM) && (Hex > 0) ){
        global_options=global_options | stringToHex(string1);
        return 1;
    }
    else
        return 0;

}
/*
*check optional order & the details matches with the options.
* if it is satisfied the conditions, it returns 1, else it returns 0
*/

int checkOptionOrder(int flag_num, char *option, char *option_details){

        int optional_flag_num=checkOptionFlag(option);
        unsigned long factor;

            if(flag_num ==2 || flag_num ==3){
                if(optional_flag_num==1){
                    factor=stringToInt(option_details);
                    if(factor > 0 && factor < 1025){
                        global_options= global_options | (factor-1) << 48 ;

                        return 1;
                    }
                    else
                        return 0;
                }
                else
                    return 0;
            }
            else if(flag_num ==4){
                if(optional_flag_num==2){
                    if(checkHex(option_details)){
                        return 1;
                    }
                    else
                        return 0;
                }
                else
                    return 0;
            }

            else
                return 0;


}



int stringCompare(char *string1, char *string2){

    int flag=0;

    for(int i=0;(*(string1+i)!='\0') ||(*(string2+i)!='\0') ;i++){

        if(*(string1+i) != *(string2+i)){
            flag++;
            break;
        }
    }

    return flag;
}

int stringToInt(char *string){
    int val=0;

    for(int i=0;*(string+i) != '\0';i++){
        val=val*10+*(string+i)-'0';
    }

    return val;
}

unsigned long stringToHex(char *string){
    unsigned long tmp=0;
    unsigned long val=0;
    int count=0;

    for(count=0; *(string+count)!='\0';count++){

    }
    for(int i=0; i<count; i++){
         if('0'<=*(string+i) && *(string+i) <='9')
                tmp=*(string+i)-'0';
            else if('a' <=*(string+i) && *(string+i) <='f')
                tmp=(*(string+i)-'a')+10;
            else
                tmp=(*(string+i)-'A')+10;

        if(i==0)
            val=tmp;
        else
            val= val<<4 | tmp;
    }

    return val;

}


