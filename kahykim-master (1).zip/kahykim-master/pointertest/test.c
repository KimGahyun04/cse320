#include <stdlib.h>
#include <stdio.h>
int main(void){

    int arr[10]={0};
    printf("%d\n",arr);
    printf("%d\n",&arr);
    return 0;

}
