#ifndef HELPER_H
#define HELPER_H

#include <stdint.h>
#include <stdlib.h>
#include "imprimer.h"
#include <stdio.h>

typedef char* type;
#define MAX_TYPES (64)


PRINTER* printerlist[MAX_PRINTERS];
char buf[1024];
char printer_buf[1024];//test
char job_buf[1024];//test
char* typelist[MAX_TYPES];
int num_types;
int imp_num_printers;
FILE* file_output;
int num_conversion;

void Sigterm_handler(int signo);
void Sigstop_handler(int signo);
void Sigcont_handler(int signo);

void cmd_help();
void cmd_quit();
int cmd_type(type file_type);
int cmd_printer(char* printer_name, type file_type);
int cmd_conversion(type old_type, type new_type, char* convert_program[], int convert_num);
void cmd_printers();
void cmd_jobs();
int cmd_print_set_file(char* file_name);
int cmd_print(char* file_name, int num_choosen_printer,char* choosen_printer_list[]);
int cmd_cancel(int job_number);
int cmd_resume(int job_number);
int cmd_pause(int job_number);
void cmd_disable(char* printer_name);
void cmd_enable(char* printer_name);
void scan_jobs();


#endif
