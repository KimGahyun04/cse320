#include <stdlib.h>
#include <stdio.h>

#include "debug.h"
#include "hw1.h"


#ifdef _STRING_H
#error "Do not #include <string.h>. You will get a ZERO."
#endif

#ifdef _STRINGS_H
#error "Do not #include <strings.h>. You will get a ZERO."
#endif

#ifdef _CTYPE_H
#error "Do not #include <ctype.h>. You will get a ZERO."
#endif

#define DATA_OFFSET_MINVAL_ANNOTAITION (32)
#define DATA_OFFSET_MINVAL (24)


/**
 * @brief  Recodes a Sun audio (.au) format audio stream, reading the stream
 * from standard input and writing the recoded stream to standard output.
 * @details  This function reads a sequence of bytes from the standard
 * input and interprets it as digital audio according to the Sun audio
 * (.au) format.  A selected transformation (determined by the global variable
 * "global_options") is applied to the audio stream and the transformed stream
 * is written to the standard output, again according to Sun audio format.
 *
 * @param  argv  Command-line arguments, for constructing modified annotation.
 * @return 1 if the recoding completed successfully, 0 otherwise.
 */
int recode(char **argv) {

   AUDIO_HEADER input_header = {0};
   AUDIO_HEADER *input_headerptr=&input_header;

   AUDIO_HEADER output_header = {0};
   AUDIO_HEADER *outout_headerptr=&output_header;

  unsigned int input_annotation_field_size;
  int preserve = (global_options & (0x1L << 59))>>61;
  int slow_down =(global_options & (0x1L << 61))>>61;
  int speed_up = (global_options & (0x1L << 62))>>62;
  int crypt = (global_options & (0x1L << 60))>>60;;
  int factor = (global_options & (0x3ffL << 48))>>48;
  unsigned int key=(global_options << 32) >>32;
  int count;
  int input_frame_size;
  int input_frame_no;
  int output_frame_no;
  unsigned int output_annotation_field_size;
  int out_count=0;
  float previous_val;
  float input_val;
  int out_val;
  float increase_val;
  int interpolation_num;
  int random_key;
  int random_key_n;
  int mask;
  char random_key_byte;
  int num_bytes_in_sample;
  int sample_count;
  int num_bytes_in_frame;

    if(read_header(input_headerptr)){
        input_annotation_field_size=input_header.data_offset - sizeof(input_header);
        if(input_annotation_field_size==0){
            if(input_header.data_offset<DATA_OFFSET_MINVAL)
                return 0;
        }
        else{
            if(input_header.data_offset<DATA_OFFSET_MINVAL_ANNOTAITION)
                return 0;
        }
      }
      else
        return 0;


    if(read_annotation(input_annotation,input_annotation_field_size)){

        if(preserve){
            for(int i=0;i<input_annotation_field_size;i++){
              output_annotation[i]=input_annotation[i];
            }
            output_annotation_field_size=input_annotation_field_size;
        }
        else{
            for(int i=0;*(argv+i)!='\0';i++){
                if(i==0)
                  count=0;
                else
                    count++;

                for(int k=0;*(*(argv+i)+k)!='\0';k++){
                  *(output_annotation+count)=*(*(argv+i)+k);
                  count++;
                }
                *(output_annotation+count)=' ';
            }
            *(output_annotation+count)='\n';
            while(1){
                count++;
                if(count % 8 == 0)
                    break;
                else
                    output_annotation[count]='\0';
            }
            output_annotation_field_size=count;
        }
    }
    else
      return 0;

    input_frame_size=input_header.channels * (input_header.encoding-1);
    if(input_header.data_size < input_frame_size)
      return 0;
    if(input_header.data_size % input_frame_size != 0)
      return 0;

    input_frame_no=input_header.data_size/input_frame_size;

    if(speed_up)
        output_frame_no=input_frame_no/(factor+1)+input_frame_no%(factor+1);
    else if(slow_down)
        output_frame_no=input_frame_no+factor*(input_frame_no-1);
    else if(crypt)
        output_frame_no=input_frame_no;
    else
        return 0;


    output_header.magic_number=input_header.magic_number;
    output_header.data_offset=sizeof(output_header)+output_annotation_field_size;
    output_header.data_size=output_frame_no*input_frame_size;
    output_header.encoding=input_header.encoding;
    output_header.sample_rate=input_header.sample_rate;
    output_header.channels=input_header.channels;


   if( write_header(outout_headerptr) && write_annotation(output_annotation,output_annotation_field_size)){
        num_bytes_in_frame=input_header.channels*(input_header.encoding-1);
        num_bytes_in_sample=input_header.encoding-1;
        out_count=0;
        if(speed_up){
            while(out_count<input_frame_no){
                if(!read_frame((int*)input_frame,input_header.channels,input_header.encoding-1))
                  return 0;
                if((out_count % (factor+1)) == 0){
                    if(!write_frame((int*)input_frame,input_header.channels,input_header.encoding-1))
                        return 0;
                }
                out_count++;
            }
        }
        else if(slow_down){
            out_count=0;
            while(out_count < input_frame_no){
                previous_val=0;
                input_val=0;
                increase_val=0;
                interpolation_num=1;

                if(!read_frame((int*)input_frame,input_header.channels,input_header.encoding-1))
                  return 0;

                if(out_count==0){
                    for(int i=0;i<num_bytes_in_frame;i++)
                        *(previous_frame+i)=*(input_frame+i);
                }
                else{
                    int check_sign =0x1 << (8*num_bytes_in_sample);

                    while(interpolation_num<factor+1){

                        for(int i=input_header.channels-1;i>-1;i--){                         ;
                             sample_count=num_bytes_in_sample-1;
                             input_val=0;
                             previous_val=0;
                             increase_val=0;

                        while(sample_count >-1){
                          input_val=((int)input_val << 8) | *(input_frame+i*num_bytes_in_sample+sample_count);
                          previous_val=((int)previous_val<<8) | *(previous_frame+i*num_bytes_in_sample+sample_count);
                          increase_val=(input_val-previous_val)/(factor+1)*interpolation_num;
                          sample_count--;
                          }
                          out_val=(int)previous_val+(int)increase_val;
                          sample_count=num_bytes_in_sample-1;
                          while(sample_count >-1){
                            *(output_frame+i*num_bytes_in_sample+sample_count)=(out_val & (0xff << (sample_count)*8))>>(sample_count)*8;
                            sample_count--;
                          }
                        }

                    if(!write_frame((int*)output_frame,output_header.channels,output_header.encoding-1))
                        return 0;

                     interpolation_num++;
                    }

                     for(int i=0;i<num_bytes_in_frame;i++){
                        *(previous_frame+i)=*(input_frame+i);
                     }
                }
                if(!write_frame((int*)input_frame,input_header.channels,input_header.encoding-1))
                    return 0;
                out_count++;
            }
        }
        else if(crypt){
            mysrand(key);
            while(out_count < input_frame_no){
                num_bytes_in_sample=input_header.encoding-1;

                if(!read_frame((int*)input_frame,input_header.channels,input_header.encoding-1))
                  return 0;

                for(int i=input_header.channels-1;i>-1;i--){
                    random_key=myrand32();
                    sample_count=num_bytes_in_sample-1;

                    while(sample_count >-1){
                        random_key_byte=random_key >> (8*sample_count);
                        *(output_frame+i*num_bytes_in_sample+sample_count)=*(input_frame+i*num_bytes_in_sample+sample_count) ^random_key_byte;
                        sample_count--;
                    }
                }

                if(!write_frame((int*)output_frame,input_header.channels,input_header.encoding-1))
                    return 0;
                out_count++;
            }
        }
    }
    else
        return 0;


    return 1;
}

/**
 * @brief Read the header of a Sun audio file and check it for validity.
 * @details  This function reads 24 bytes of data from the standard input and
 * interprets it as the header of a Sun audio file.  The data is decoded into
 * six unsigned int values, assuming big-endian byte order.   The decoded values
 * are stored into the AUDIO_HEADER structure pointed at by hp.
 * The header is then checked for validity, which means:  no error occurred
 * while reading the header data, the magic number is valid, the data offset
 * is a multiple of 8, the value of encoding field is one of {2, 3, 4, 5},
 * and the value of the channels field is one of {1, 2}.
 *
 * @param hp  A pointer to the AUDIO_HEADER structure that is to receive
 * the data.
 * @return  1 if a valid header was read, otherwise 0.
 */
int read_header(AUDIO_HEADER *hp){
    int ch;

   for(int i=0;i<4;i++){
    if((ch=getchar())!=EOF)
      hp->magic_number=hp->magic_number << 8 | ch;
    else
      return 0;
   }
   for(int i=0;i<4;i++){
     if((ch=getchar())!=EOF)
        hp->data_offset=hp->data_offset <<8 | ch;
      else
        return 0;

   }
   for(int i=0;i<4;i++){
     if((ch=getchar())!=EOF)
        hp->data_size=hp->data_size << 8 | ch;
      else
        return 0;
   }
   for(int i=0;i<4;i++){
     if((ch=getchar())!=EOF)
        hp->encoding=hp->encoding << 8 | ch;
      else
        return 0;
   }
    for(int i=0;i<4;i++){
     if((ch=getchar())!=EOF)
          hp->sample_rate=hp->sample_rate << 8 | ch;
        else
          return 0;
   }
    for(int i=0;i<4;i++){
     if((ch=getchar())!=EOF)
        hp->channels=hp->channels <<8 | ch;
      else
        return 0;
   }

    if(hp->magic_number != AUDIO_MAGIC)
        return 0;


    if(hp->data_offset % 8 != 0)
        return 0;


    if(hp->encoding <PCM8_ENCODING || hp->encoding > PCM32_ENCODING)
        return 0;


    if(hp->channels < 1 && hp->channels > CHANNELS_MAX)
        return 0;

    return 1;
}

/**
 * @brief  Write the header of a Sun audio file to the standard output.
 * @details  This function takes the pointer to the AUDIO_HEADER structure passed
 * as an argument, encodes this header into 24 bytes of data according to the Sun
 * audio file format specifications, and writes this data to the standard output.
 *
 * @param  hp  A pointer to the AUDIO_HEADER structure that is to be output.
 * @return  1 if the function is successful at writing the data; otherwise 0.
 */
int write_header(AUDIO_HEADER *hp){
    int error_count = 0;

    for(int i=0;i<4;i++){
      int tmp=0x01;
      tmp = hp->magic_number >> (24-i*8);
      if(putchar(tmp)==EOF)
        error_count++;

    }
    for(int i=0;i<4;i++){
      int tmp=0x01;
      tmp = hp->data_offset >> (24-i*8);
      if(putchar(tmp)==EOF)
        error_count++;
    }
    for(int i=0;i<4;i++){
      int tmp=0x01;
      tmp = hp->data_size >> (24-i*8);
      if(putchar(tmp)==EOF)
        error_count++;
    }
    for(int i=0;i<4;i++){
      int tmp=0x01;
      tmp = hp->encoding >> (24-i*8);
      if(putchar(tmp)==EOF)
        error_count++;
    }
    for(int i=0;i<4;i++){
      int tmp=0x01;
      tmp = hp->sample_rate >> (24-i*8);
      if(putchar(tmp)==EOF)
        error_count++;
    }
    for(int i=0;i<4;i++){
      int tmp=0x01;
      tmp = hp->channels >> (24-i*8);
      if(putchar(tmp)==EOF)
        error_count++;
    }
    if(error_count>0)
        return 0;

    return 1;
}

/**
 * @brief  Read annotation data for a Sun audio file from the standard input,
 * storing the contents in a specified buffer.
 * @details  This function takes a pointer 'ap' to a buffer capable of holding at
 * least 'size' characters, and it reads 'size' characters from the standard input,
 * storing the characters read in the specified buffer.  It is checked that the
 * data read is terminated by at least one null ('\0') byte.
 *
 * @param  ap  A pointer to the buffer that is to receive the annotation data.
 * @param  size  The number of bytes of data to be read.
 * @return  1 if 'size' bytes of valid annotation data were successfully read;
 * otherwise 0.
 */
int read_annotation(char *ap, unsigned int size){
  int ch;

    if(size > ANNOTATION_MAX )
        return 0;

    if(size==0)
        return 1;

    for(int i=0;i<size;i++){
      if((ch=getchar())!=EOF)
          *(ap+i)=ch;
        else
          return 0;

    }
    if(*(ap+size-1)=='\0'){
      return 1;
    }
    else
      return 0;
}

/**
 * @brief  Write annotation data for a Sun audio file to the standard output.
 * @details  This function takes a pointer 'ap' to a buffer containing 'size'
 * characters, and it writes 'size' characters from that buffer to the standard
 * output.
 *
 * @param  ap  A pointer to the buffer containing the annotation data to be
 * written.
 * @param  size  The number of bytes of data to be written.
 * @return  1 if 'size' bytes of data were successfully written; otherwise 0.
 */
int write_annotation(char *ap, unsigned int size){

    int i;
    int out=0x01;
    int error_count=0;

    if(size > ANNOTATION_MAX )
        return 0;

    for(i=0;*(ap+i)!='\0';i++){
        if(putchar(*(ap+i))==EOF)
            error_count++;
    }


    for(;i<size;i++){
        if(putchar(0)==EOF)
            error_count++;
    }
    if(error_count>0)
        return 0;


    return 1;
}

/**
 * @brief Read, from the standard input, a single frame of audio data having
 * a specified number of channels and bytes per sample.
 * @details  This function takes a pointer 'fp' to a buffer having sufficient
 * space to hold 'channels' values of type 'int', it reads
 * 'channels * bytes_per_sample' data bytes from the standard input,
 * interpreting each successive set of 'bytes_per_sample' data bytes as
 * the big-endian representation of a signed integer sample value, and it
 * stores the decoded sample values into the specified buffer.
 *
 * @param  fp  A pointer to the buffer that is to receive the decoded sample
 * values.
 * @param  channels  The number of channels.
 * @param  bytes_per_sample  The number of bytes per sample.
 * @return  1 if a complete frame was read without error; otherwise 0.
 */
int read_frame(int *fp, int channels, int bytes_per_sample){
    int num_bytes_in_frame = (channels * bytes_per_sample);
    int count;
    int ch;

    if(num_bytes_in_frame>CHANNELS_MAX * sizeof(int))
        return 0;

      if(num_bytes_in_frame < 4){
          while(num_bytes_in_frame>0){
            if((ch=getchar())!=EOF)
              *fp=(*fp << 8) | ch;
            else
              return 0;

            num_bytes_in_frame--;
          }

      } else{
          for(int i=0; i<num_bytes_in_frame/4;i++){
            count=0;
            while(count<4){
              if((ch=getchar())!=EOF)
                  *(fp+i)=(*(fp+i) << 8) | ch;
                else
                   return 0;
              count++;
            }
          }

      }

    return 1;
}

/**
 * @brief  Write, to the standard output, a single frame of audio data having
 * a specified number of channels and bytes per sample.
 * @details  This function takes a pointer 'fp' to a buffer that contains
 * 'channels' values of type 'int', and it writes these data values to the
 * standard output using big-endian byte order, resulting in a total of
 * 'channels * bytes_per_sample' data bytes written.
 *
 * @param  fp  A pointer to the buffer that contains the sample values to
 * be written.
 * @param  channels  The number of channels.
 * @param  bytes_per_sample  The number of bytes per sample.
 * @return  1 if the complete frame was written without error; otherwise 0.
 */
int write_frame(int *fp, int channels, int bytes_per_sample){
     int num_bytes_in_frame = channels * bytes_per_sample;
     char out;
     int count;
     int error_count=0;
     if(num_bytes_in_frame < 4){
      count=0;
      while(count<num_bytes_in_frame){
         out = *fp >> (8*(num_bytes_in_frame-count-1));
            if(putchar(out)==EOF)
                error_count++;
            count++;
      }
     }else{
          for(int i=0;i<num_bytes_in_frame/4;i++){
            count = 0;
            while(count < 4){
                out = *(fp+i) >> (24-count*8);
                if(putchar(out)==EOF)
                    error_count++;
                count++;

            }
         }

     }

     if(error_count>0)
        return 0;

    return 1;
}



