
#define BANNER "GRADES (version 0.51, March 9, 1992 -- with CSE320 mods)\n\n"

