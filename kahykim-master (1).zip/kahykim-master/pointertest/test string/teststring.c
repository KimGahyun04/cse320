#include <stdio.h>
#include <string.h>

int main(){
    char str[]="JavaTpoint";
    printf("%d\n",strlen(str));
    return 0;
}