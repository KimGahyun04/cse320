#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include "helper.h"
#include <string.h>
#include "imprimer.h"
#include <fcntl.h>
#include <unistd.h>
#include "job_handler.h"
#include "sig_handler.h"
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <signal.h>

char change_buf[1024];//test

void change_status(int jobid, int job_status){
    job_list[jobid]->status=job_status;
    gettimeofday(&job_list[jobid]->change_time,NULL);
    imp_format_job_status(job_list[jobid],change_buf,sizeof(change_buf));
    fprintf(file_output,"%s\n",change_buf);
    strcpy(change_buf,"");
    if(job_status==COMPLETED || job_status ==ABORTED){
        if(job_list[jobid]->chosen_printer!=NULL){
            if(job_list[jobid]->chosen_printer->busy==1){
                job_list[jobid]->chosen_printer->busy=0;
                imp_format_printer_status(job_list[jobid]->chosen_printer,change_buf,sizeof(change_buf));
                fprintf(file_output,"%s\n",change_buf);
                strcpy(change_buf,"");
            }
        }
    }

}
void master_sig_handler(int signo){
    pid_t pid;
    int status;
    while((pid=waitpid(-1,&status,WNOHANG))>0){
        for(int i=0;i<num_jobs;i++){
            if(job_list[i]->pgid==pid){
                if(WIFEXITED(status)){
                    got_sig=1;
                    break;
                }
            }
        }
    }
}

