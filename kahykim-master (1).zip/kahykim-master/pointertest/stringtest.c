#include <stdio.h>
#include <string.h>
#define X 5+7

union a{
    int a;
    char b[4];

};

int main(){

    union a A;
    A.a=0;
    A.b[0]='a';
    A.b[2]='b';
    int arr[2][3][4];
    arr[1][1][2]=10;
    printf("%d",*(*((*arr+1)+1)+2));

    printf("%s",A.b);
    printf("%d",X+5+7);
    return 0;

}