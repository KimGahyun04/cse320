#ifndef SIG_HANDLER_H
#define SIG_HANDLER_H

#include <stdint.h>
#include <stdlib.h>
#include "imprimer.h"
#include <signal.h>

void master_sig_handler(int signo);
void change_status(int jobid, int job_status);
volatile sig_atomic_t got_sig;


#endif