#include "store.h"
#include "csapp.h"
#include "string.h"
#include "debug.h"

struct map The_Map;
/*
 * Initialize the store.
 */
BLOB* add_version(MAP_ENTRY* map_entry, TRANSACTION *tp, BLOB *value ,char* from);
MAP_ENTRY* find_map_entry(TRANSACTION *tp, KEY* key, char* from);
void store_init(void){
    debug("Initialize object store");
    The_Map.table=Malloc(NUM_BUCKETS*sizeof(MAP_ENTRY*));
    The_Map.num_buckets=NUM_BUCKETS;
    for(int i=0;i<NUM_BUCKETS;i++){
        The_Map.table[i]=NULL;
    }
    if(pthread_mutex_init(&The_Map.mutex,NULL)!=0){
        perror("mutex fails\n");//test
    }

}

/*
 * Finalize the store.
 */
void store_fini(void){
    debug("Finalize object store");
    for(int i=0;i<NUM_BUCKETS;i++){
        MAP_ENTRY* map_entry;
        map_entry=The_Map.table[i];
        while(1){
            if(map_entry==NULL)
                break;
            key_dispose(map_entry->key);
            VERSION* version=map_entry->versions;
            while(1){
                if(version==NULL)
                    break;
                version_dispose(version);
                version=version->next;

            }
            map_entry=map_entry->next;
        }
        Free(The_Map.table[i]);
    }
    Free(The_Map.table);

}
/*
 * Put a key/value mapping in the store.  The key must not be NULL.
 * The value may be NULL, in which case this operation amounts to
 * deleting any existing mapping for the given key.
 *
 * This operation inherits the key and consumes one reference on
 * the value.
 *
 * @param tp  The transaction in which the operation is being performed.
 * @param key  The key.
 * @param value  The value.
 * @return  Updated status of the transation, either TRANS_PENDING,
 *   or TRANS_ABORTED.  The purpose is to be able to avoid doing further
 *   operations in an already aborted transaction.
 */
TRANS_STATUS store_put(TRANSACTION *tp, KEY *key, BLOB *value){
    if(key==NULL)
        return TRANS_ABORTED;
    debug("put mapping (key %p[%s] -> value %p[%s]) in store for transaction %d",key,key->blob->prefix,value,
        value->prefix,tp->id);
    MAP_ENTRY* m_entry=find_map_entry(tp,key,"put");
    if(m_entry->key==NULL)
        debug("key is NULL");
    if(m_entry==NULL)
        return TRANS_ABORTED;
    add_version(m_entry,tp,value,"put");
    if(trans_get_status(tp)==TRANS_ABORTED){
        debug("trans aboort");
        return TRANS_ABORTED;
    }

    return TRANS_PENDING;
}
/*
 * Get the value associated with a specified key.  A pointer to the
 * associated value is stored in the specified variable.
 *
 * This operation inherits the key.  The caller is responsible for
 * one reference on any returned value.
 *
 * @param tp  The transaction in which the operation is being performed.
 * @param key  The key.
 * @param valuep  A variable into which a returned value pointer may be
 *   stored.  The value pointer store may be NULL, indicating that there
 *   is no value currently associated in the store with the specified key.
 * @return  Updated status of the transation, either TRANS_PENDING,
 *   or TRANS_ABORTED.  The purpose is to be able to avoid doing further
 *   operations in an already aborted transaction.
 */
TRANS_STATUS store_get(TRANSACTION *tp, KEY *key, BLOB **valuep){
    if(key==NULL)
        return TRANS_ABORTED;
    debug("Get mapping of key %p[%s] in store for transaction %d",key,key->blob->prefix,tp->id);
    MAP_ENTRY* m_entry=find_map_entry(tp,key,"get");
    if(m_entry==NULL)
        return TRANS_ABORTED;
    BLOB* result=add_version(m_entry,tp,NULL,"get");
    *valuep=result;
    if(result==NULL){
        if(trans_get_status(tp)==TRANS_ABORTED){
            return TRANS_ABORTED;//test
        }
    }
    else{
        blob_ref(result,"for returning form store_get");//test
    }
    //*valuep=result;
    return TRANS_PENDING;
}

MAP_ENTRY* find_map_entry(TRANSACTION *tp, KEY* key, char* from){
    int mod_hash;
    mod_hash=key->hash % NUM_BUCKETS;
    MAP_ENTRY *map_entry=Malloc(sizeof(MAP_ENTRY));
    map_entry->key=key;
    map_entry->versions=NULL;
    map_entry->next=NULL;

    if(The_Map.table[mod_hash]==NULL){
        debug("Create new map entry for key %p[%s] at table index %d",key,key->blob->prefix,mod_hash);
        pthread_mutex_lock(&The_Map.mutex);
        The_Map.table[mod_hash]=map_entry;
        pthread_mutex_unlock(&The_Map.mutex);
        return map_entry;
    }
    else{
        MAP_ENTRY *tmp;
        tmp=The_Map.table[mod_hash];
        while(1){
            if(key_compare(tmp->key,map_entry->key)==0){
                debug("Matching entry exists, disposing of redundant key %p[%s]",tmp->key,tmp->key->blob->prefix);
                key_dispose(tmp->key);
                tmp->key=key;
                return tmp;
                //if key already exists
            }
            if(tmp->next==NULL){
                debug("Create new map entry for key %p[%s] at table index %d",key,key->blob->prefix,mod_hash);
                pthread_mutex_lock(&The_Map.mutex);
                tmp->next=map_entry;
                 pthread_mutex_unlock(&The_Map.mutex);
                return map_entry;
            }
            tmp=tmp->next;
        }
        return NULL;
    }


}
BLOB* add_version(MAP_ENTRY* map_entry, TRANSACTION *tp, BLOB *value ,char* from){

    debug("Trying to %s version in map entry for key %p[%s]",from,map_entry->key,map_entry->key->blob->prefix);
    VERSION* new_version;
    if(map_entry->versions!=NULL){
        debug("Examine version %p for key %p[%s]",
            map_entry->versions,map_entry->key,map_entry->key->blob->prefix);
        VERSION* tmp_version=map_entry->versions;
        while(1){
            if(tp->id < tmp_version->creator->id){
                debug("Current transaction ID(%d) is less than version creator (%d) -- aborting",
                    tp->id,tmp_version->creator->id);
                trans_ref(tp,"for referecnce to current transaction for aborting");
                trans_abort(tp);
                //trans_show(tp);//test
                return NULL;

            }
            if(tmp_version->creator->id==tp->id){
                if(value==NULL){
                    blob_ref(tmp_version->blob,"for new version");
                    new_version=version_create(tp,tmp_version->blob);
                }else{
                    new_version=version_create(tp,value);
                }

                debug("Replace existing version for key %p[%s]",map_entry->key,map_entry->key->blob->prefix);
                VERSION* tmp=tmp_version;
                if(tmp_version->next==NULL && tmp_version->prev==NULL){
                    map_entry->versions=new_version;
                }else{
                    tmp_version->prev->next=new_version;
                    new_version->prev=tmp_version->prev;
                    if(tmp_version->next!=NULL){
                        tmp_version->next->prev=new_version;
                        new_version->next=tmp_version->next;
                    }
                }
                debug("tp=%p(%d) creator=%p(%d)",tp,map_entry->key->hash % NUM_BUCKETS,
                    tmp_version->creator,map_entry->key->hash % NUM_BUCKETS);
                version_dispose(tmp);
                return new_version->blob;
            }
            if(tmp_version->next==NULL){
                trans_add_dependency(tp,tmp_version->creator);
                if(value==NULL){
                    blob_ref(tmp_version->blob,"for new version");
                }
                new_version=version_create(tp,tmp_version->blob);//test
                new_version->prev=tmp_version;
                tmp_version->next=new_version;
                debug("Add new version for key %p[%s]",map_entry->key,map_entry->key->blob->prefix);
                break;
            }
            tmp_version=tmp_version->next;
        }

        //just add version
    }
    else{
        new_version=version_create(tp,value);
        map_entry->versions=new_version;
        debug("Add new version for key %p[%s]",map_entry->key,map_entry->key->blob->prefix);
    }
    if(new_version->prev==NULL){
        debug("no Previous version");
    }else{
        if(new_version->prev->blob==NULL){
            debug("Previous version is %p(NULL blob)",new_version->prev);
        }
        else
            debug("Previous version is %p[%s]",new_version->prev->blob,new_version->prev->blob->prefix);
    }
    return new_version->blob;
}

void store_show(void){
    char* status;
    MAP_ENTRY* map_entry;
    fprintf(stderr,"contents of store: \n");
    for(int i=0;i<NUM_BUCKETS;i++){
        fprintf(stderr,"%d : \t",i);
        if(The_Map.table[i]!=NULL){
            map_entry=The_Map.table[i];
            while(1){
                if(map_entry==NULL)
                    break;
                VERSION* versions=map_entry->versions;
                fprintf(stderr,"{key:%p[%s],",map_entry->key,map_entry->key->blob->prefix);
                while(1){
                    if(versions==NULL)
                        break;
                    if(trans_get_status(versions->creator)==TRANS_PENDING){
                        status="pending";
                    }
                    else if(trans_get_status(versions->creator)==TRANS_ABORTED){
                        status="aborted";
                    }
                    else if(trans_get_status(versions->creator)==TRANS_COMMITTED){
                        status="commited";
                    }
                    else{
                        return;
                    }
                    if(versions->blob==NULL){
                        fprintf(stderr,"versions : {creator=%d (%s),blob=NULL blob}}",
                            versions->creator->id,status);
                    }else{
                        fprintf(stderr,"versions : {creator=%d (%s),blob=%p[%s]}}",
                        versions->creator->id,status,versions->blob,versions->blob->prefix);

                    }
                    versions=versions->next;
                }
                fprintf(stderr,"\n");
                map_entry=map_entry->next;
            }

        }
        fprintf(stderr,"\n");
    }

}

