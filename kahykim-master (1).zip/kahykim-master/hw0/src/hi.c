#include "hi.h" /* This is our headerfile */

/**
 * Here's the actual definition of our say_hi() function
 * as you can see it simply returns the string "Hi" Or does it??
 */

char* say_hi(){

    return "Hi";
}
/* Back over to main to finish our program */
