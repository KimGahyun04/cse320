#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include "helper.h"
#include <string.h>
#include "imprimer.h"
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <stdarg.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include "type_convert.h"
#include "job_handler.h"
#include "sig_handler.h"


/*
*Help command takes no arguments, and it responds by printing a message that lists
*all of the types of commands understood by the program.
*/
void sigchild_handler(int singno);
int find_file_ID(type this_type);
int find_printer(type this_type,PRINTER_SET eligible_set);
void convert_process(JOB* print_job ,int printer_id);
int check_convert_program(type this_type,PRINTER_SET eligible_set);
int find_convert_program(int old_type, int new_type);
void master_convert(JOB* print_job, int printer_id);
CONVERT* find_convert_order(int convert_num, int old_type, int new_type);

int check_valid_job(int job_number){
    int job_match=0;
    for(int i=0;i<num_jobs;i++){
        if(job_number==job_list[i]->jobid){
            job_match=1;
            break;
        }
    }
    if(job_match==0)
        imp_format_error_message("this is invalid job numbers.\n",buf,sizeof(buf));
    return job_match;

}
int cmd_cancel(int job_number){
    if(!check_valid_job(job_number))
        return 0;

    if(job_list[job_number]->status==RUNNING){//test
        killpg(job_list[job_number]->pgid,SIGTERM);
    }
    change_status(job_number, ABORTED);
    return 1;
}
int cmd_pause(int job_number){
     if(!check_valid_job(job_number))
        return 0;

    if(job_list[job_number]->status==RUNNING){
        killpg(job_list[job_number]->pgid,SIGSTOP);
    }

    return 1;
}

int cmd_resume(int job_number){
    if(!check_valid_job(job_number))
        return 0;
    if(job_list[job_number]->status==PAUSED){
        killpg(job_list[job_number]->pgid,SIGCONT);
    }
    return 1;
}
void cmd_disable(char* printer_name){
    int printer_match=0;
    for(int i=0;i<imp_num_printers;i++){
        if(strcmp(printerlist[i]->name,printer_name)==0){
            if(printerlist[i]->enabled!=0){
                imp_format_error_message("It is already disabled.\n",buf,sizeof(buf));
            }
            printerlist[i]->enabled=0;
            imp_format_printer_status(printerlist[i],buf,sizeof(buf));
            fprintf(file_output,"%s\n",buf);
            strcpy(buf,"");
            printer_match=1;
            break;
        }
    }
    if(printer_match==0){
        imp_format_error_message("this printer is not in the printer lists.\n",buf,sizeof(buf));
        return;
    }
}
void cmd_enable(char* printer_name){
    int printer_match=0;
    for(int i=0;i<imp_num_printers;i++){
        if(strcmp(printerlist[i]->name,printer_name)==0){
            if(printerlist[i]->enabled==1){
                imp_format_error_message("It is already eisabled.\n",buf,sizeof(buf));
            }
            printerlist[i]->enabled=1;
            printer_match=1;
            imp_format_printer_status(printerlist[i],printer_buf,sizeof(printer_buf));
            fprintf(file_output,"%s\n",printer_buf);
            strcpy(printer_buf,"");
            break;
        }
    }
    if(printer_match==0){
        imp_format_error_message("this printer is not in the printer lists.\n",buf,sizeof(buf));
        return;
    }
}


void cmd_help(){
    strcpy(buf,"Imprimer has 4 types of command"
            "\n Miscellaneous commands : help, quit"
            "\n Configuration commands : type, printer, converstion"
            "\n Information commands: printers, jobs"
            "\n Spooling commands : print, cancel, pause, resume, disable, enable"
            "\n");

}
/*
*The quit command takes no arguments and causes excution to terminate
*/

void cmd_quit(){
    fclose(file_output);
    for(int i=0;i<num_jobs;i++){
        free(job_list[i]);
    }
    free(job_list);
    exit(EXIT_SUCCESS);
}
int cmd_type(type file_type){
    if(num_types > MAX_TYPES){
        imp_format_error_message("you can not declare more than 64 types.\n",buf,sizeof(buf));
        return 0;
    }
    for (int i=0;i<num_types;i++){
        if(strcmp(typelist[i],file_type)==0){
            imp_format_error_message("this file type already exists\n",buf,sizeof(buf));
            return 0;
        }
    }
    typelist[num_types]=malloc(sizeof(char)*(strlen(file_type)+1));
    strcpy(typelist[num_types],file_type);
    num_types++;
    return 1;


}

int cmd_printer(char* printer_name, type file_type){
    int type_flag=0;
    if(imp_num_printers > MAX_PRINTERS-1){
        imp_format_error_message("you can not declare over 32 printers.\n",buf,sizeof(buf));
        return 0;
    }
    for(int i=0;i<imp_num_printers;i++){
        if(strcmp(printerlist[i]->name,printer_name)==0){
            imp_format_error_message("this printer name already exists.\n",buf,sizeof(buf));
            return 0;
        }
    }
    for(int i=0;i<num_types;i++){
        if(strcmp(typelist[i],file_type)==0){
            type_flag=1;
            break;
        }
    }
    if(type_flag==0){
        imp_format_error_message("you should type the valid file type.\n",buf,sizeof(buf));
        return 0;
    }

    PRINTER* printer=(PRINTER *)malloc(sizeof(PRINTER));
    //printer->name=(char*)malloc(strlen(printer_name));
    //printer->type=(char*)malloc(strlen(file_type));
    printer->name=printer_name;
    printer->type=file_type;
    printer->id=imp_num_printers;
    printer->enabled=1;
    printer->busy=0;
    printer->other_info=NULL;
    printerlist[imp_num_printers]=printer;
    imp_num_printers++;

    return 1;
}

void cmd_printers(){
    if(imp_num_printers==0){
        strcpy(buf,"There's no printer in the printerlist\n");
        return;
    }
    for(int i=0;i<imp_num_printers;i++){
        imp_format_printer_status(printerlist[i],printer_buf,sizeof(printer_buf));
        fprintf(file_output,"%s\n",printer_buf);
        strcpy(printer_buf,"");
    }


}
void cmd_jobs(){

    if(num_jobs==0){
        strcpy(buf,"There's no jobs in the joblist\n");
        return;
    }
    printf("number jobs : %d\n",num_jobs);
    for(int i=0;i<num_jobs;i++){
        imp_format_job_status(job_list[i],job_buf,sizeof(job_buf));
        fprintf(file_output,"%s\n",job_buf);
        strcpy(job_buf,"");
    }

}

int make_matrix(int type){
    for(int i=0;i<num_types;i++){
        if(convert_matrix[type][i]>0)
            return i;
    }
    return -1;
}
int cmd_conversion(type old_type, type new_type, char* convert_program[], int convert_num){
    int old_type_match=0;
    int new_type_match=0;
    int already_exists=0;
    int new;
    CONVERT cur_convert;
    if(old_type ==NULL || new_type ==NULL){
        imp_format_error_message("you should use declared type to conversion.\n",buf,sizeof(buf));
        return 0;
    }
    if(convert_program[0]==NULL){
        imp_format_error_message("invalid convert program.\n",buf,sizeof(buf));
        return 0;
    }
    for(int i=0;i<num_types;i++){
        if(strcmp(old_type,typelist[i])==0){
            cur_convert.old_type_ID=i;
            old_type_match=1;
          }
        if(strcmp(new_type,typelist[i])==0){
            cur_convert.new_type_ID=i;
            new_type_match=1;
        }

    }
    if(!old_type_match || !new_type_match){
        imp_format_error_message("you should use declared type to conversion.\n",buf,sizeof(buf));
        return 0;
    }

    if(convert_program[0]==NULL){
       imp_format_error_message("you need to give convert program.\n",buf,sizeof(buf));
       return 0;
    }
    if(strcmp(old_type,new_type)==0){
       imp_format_error_message("you don't need to convert file.\n",buf,sizeof(buf));
       return 0;
    }
    //sigset_t sigset;

    if(convert_matrix[cur_convert.old_type_ID][cur_convert.new_type_ID]==1){
        imp_format_error_message("this conversion program is alaredy existed.\n",buf,sizeof(buf));
        return 0;
    }
    cur_convert.next_convert=NULL;
    cur_convert.prev_convert=NULL;
    cur_convert.convert_program=NULL;//test
    cur_convert.convert_program=malloc(sizeof(char*)*(convert_num+1));
    for(int i=0;i<convert_num;i++){
        cur_convert.convert_program[i]=malloc(strlen(convert_program[i])+1);
        strcpy(cur_convert.convert_program[i],convert_program[i]);
    }

    convert_matrix[cur_convert.old_type_ID][cur_convert.new_type_ID]=1;

    cur_convert.convert_program[convert_num]=NULL; //make last arguement is NULL

    for(int k=0;k<num_conversion;k++){
        if(convert_list[k].old_type_ID==cur_convert.old_type_ID && convert_list[k].new_type_ID==cur_convert.new_type_ID){
            convert_list[k]=cur_convert;
            already_exists=1;
            break;
        }
    }
    if(already_exists==0){
        convert_list[num_conversion]=cur_convert;
        num_conversion++;

    }

    for(int i=0;i<num_types;i++){
        for(int j=0;j<num_types;j++){
            if(convert_matrix[i][j]>0){
                new=make_matrix(j);
                if(new>-1){
                  CONVERT new_conv;
                  CONVERT* prev_conv;
                  CONVERT* next_conv;
                  int list_in=0;
                  for(int k=0;k<num_conversion;k++){
                    if(convert_list[k].old_type_ID==i && convert_list[k].new_type_ID==j)
                        prev_conv=&convert_list[k];
                    if(convert_list[k].old_type_ID==j && convert_list[k].new_type_ID==new)
                        next_conv=&convert_list[k];
                    if(convert_list[k].old_type_ID==i && convert_list[k].new_type_ID==new)
                        list_in=1;
                  }
                  if(list_in!=1){
                      new_conv.old_type_ID=i;
                      new_conv.new_type_ID=new;
                      new_conv.convert_program=NULL;
                      new_conv.prev_convert=prev_conv;
                      new_conv.next_convert=next_conv;
                      convert_list[num_conversion]=new_conv;
                      num_conversion++;
                  }
                  if(already_exists==0)
                        convert_matrix[i][new]=convert_matrix[i][j]+convert_matrix[j][new];

                }
            }
        }

    }

    return 1;

  }

int cmd_print(char* file_name,int num_choosen_printer, char* choosen_printer_list[]){
    PRINTER_SET eligible_printer_set=0;
    int printer_match=0;
    char* f_type=NULL;
    if(strstr(file_name,".")==NULL){
        imp_format_error_message("Invalid file!\n",buf,sizeof(buf));
        return 0;
    }
    f_type=strrchr(file_name,'.');
    int type_match=0;
    for(int i=0;i<num_types;i++){
        if(strstr(f_type,typelist[i])){
            type_match=1;
            break;
        }
    }
    if(!type_match){
        imp_format_error_message("this file type doesn't exists in typelist.\n",buf,sizeof(buf));
        return 0;
    }

    if(num_choosen_printer==0){
        eligible_printer_set=ANY_PRINTER;

    }
    else{
        for(int i=0;i<num_choosen_printer;i++){
            for(int k=0;k<imp_num_printers;k++){
                if(strcmp(printerlist[k]->name,choosen_printer_list[i])==0){
                    eligible_printer_set=eligible_printer_set | (0x1 << printerlist[k]->id);
                    printer_match++;
                    break;
                }
            }
            if(printer_match==0){
                imp_format_error_message("this printer is not in the printerlist.\n",buf,sizeof(buf));
                return 0;
            }
        }
    }
    JOB* job=(JOB*)malloc(sizeof(JOB));
    job->jobid=job_id;
    job->chosen_printer=NULL;
    job->file_type=f_type+1;
    job->status=QUEUED;
    job->pgid=0;
    job->file_name=file_name;
    job->eligible_printers=eligible_printer_set;
    job->other_info=NULL;
    gettimeofday(&job->creation_time,NULL);
    gettimeofday(&job->change_time,NULL);
    job_list[num_jobs]=job;
    num_jobs++;
    job_id++;
    return 1;
}

int find_printer(type this_type,PRINTER_SET eligible_set){
    int printer_id=-1;

    if(eligible_set==ANY_PRINTER){
        for(int i=0;i<imp_num_printers;i++){
            if(strcmp(printerlist[i]->type,this_type)==0){
                if((printerlist[i]->enabled!=0) && (printerlist[i]->busy==0)){
                    printer_id=i;
                    break;
                }
            }
        }
    }
    else{
        for(int count=0;count<imp_num_printers;count++){
            if(eligible_set & (0x1 << printerlist[count]->id)){
                if(strcmp(printerlist[count]->type,this_type)==0){
                    if((printerlist[count]->enabled!=0) && (printerlist[count]->busy==0)){
                        printer_id=count;
                        break;
                    }
                }
            }
        }
    }
    return printer_id;
}
int find_file_ID(type this_type){
    int type_id=-1;
    for(int i=0;i<num_types;i++){
            if(strcmp(typelist[i],this_type)==0){
                type_id=i;
            }
        }
    return type_id;

}
int check_convert_program(type this_type,PRINTER_SET eligible_set){
    int type_id;
    int print_id;

    if((print_id=find_printer(this_type,eligible_set))!=-1){
        return print_id;
    }
    else{
        type_id=find_file_ID(this_type);
        for(int i=0;i<num_types;i++){
            if(convert_matrix[type_id][i]>0){
                if((print_id=check_convert_program(typelist[i],eligible_set))!=-1){
                    return print_id;
                }
            }
        }
    }
    return -1;

}
void scan_jobs(){
    int printer_id=-1;
    struct timeval current_time;
    double timediff;
    gettimeofday(&current_time,NULL);
    for(int i=0;i<num_jobs;i++){
        if(job_list[i]->status==QUEUED){
            if((printer_id=check_convert_program(job_list[i]->file_type,job_list[i]->eligible_printers))>-1){
                printerlist[printer_id]->busy=1;
                job_list[i]->chosen_printer=printerlist[printer_id];
                master_convert(job_list[i],printer_id);

            }
        }
        if(job_list[i]->status==COMPLETED || job_list[i]->status==ABORTED){
            timediff=current_time.tv_sec-job_list[i]->change_time.tv_sec;
            if(timediff>60)
                delete_job(job_list[i]->jobid);
        }
    }
}



void master_convert(JOB* print_job, int printer_id){
    pid_t master_pid;
    print_job->status=RUNNING;
    gettimeofday(&(*print_job).change_time,NULL);

    signal(SIGCHLD,master_sig_handler);
    sigset_t sigset,prev_set;
    sigemptyset(&sigset);
    sigaddset(&sigset,SIGCHLD);
    sigprocmask(SIG_BLOCK,&sigset,&prev_set);
    master_pid=fork();
    if(master_pid<0){
        perror("fork error");
        exit(-1);
    }else if(master_pid==0){
        setpgid(master_pid,getpid());
        sigprocmask(SIG_SETMASK,&prev_set,NULL);
        convert_process(print_job,printer_id);
    }else{
        print_job->pgid=master_pid;
        sigprocmask(SIG_SETMASK,&prev_set,NULL);
        imp_format_job_status(print_job,job_buf,sizeof(job_buf));
        fprintf(file_output,"%s\n",job_buf);
        strcpy(job_buf,"");
        imp_format_printer_status(print_job->chosen_printer,buf,sizeof(buf));
        fprintf(file_output,"%s\n",buf);
        strcpy(buf,"");
        pause();//test
        if(got_sig){
            change_status(print_job->jobid,COMPLETED);
            got_sig=0;
        }
    }
}

void convert_process(JOB* print_job, int printer_id){

    int orig_type=find_file_ID(print_job->file_type);
    int new_type=find_file_ID(printerlist[printer_id]->type);
    int convert_times=1;
    int pipelines=0;
    pid_t childs;
    pid_t child_pid[convert_times];
    int status;
    int file_out;
    int file_fd;
    sigset_t sigset;
    sigemptyset(&sigset);
    sigaddset(&sigset,SIGCHLD);

    char* argv[]={"/bin/cat",NULL};//test
    if(orig_type!=new_type)
        convert_times=convert_matrix[orig_type][new_type];

    CONVERT* convert=find_convert_order(convert_times,orig_type,new_type);
    int fd[convert_times][2];
    for(int i=0;i<convert_times;i++)
        pipe(fd[i]);

    while(pipelines<convert_times){
        sigprocmask(SIG_BLOCK,&sigset,NULL);
        child_pid[pipelines]=fork();
        if(child_pid[pipelines]==-1){
            perror("fork error");
            exit(EXIT_FAILURE);
        }else if(child_pid[pipelines]==0){
            sigprocmask(SIG_UNBLOCK,&sigset,NULL);
            if(pipelines==0){
                file_fd=open(print_job->file_name,O_RDONLY);

            if(file_fd<0){
                imp_format_error_message("there's no file existed.\n",buf,sizeof(buf));
                exit(EXIT_FAILURE);
            }
                dup2(file_fd,0);
                close(file_fd);
            }else{
                dup2(fd[pipelines-1][0],0);
            }

            if(pipelines+1==convert_times){
                for(int i=0;i<convert_times;i++){
                    close(fd[i][0]);
                    close(fd[i][1]);
                }//test
                dup2(file_out=imp_connect_to_printer(printerlist[printer_id],PRINTER_NORMAL),1);
                if(file_out<0){
                    exit(EXIT_FAILURE);
                }
                close(file_out);
            }else{
                 dup2(fd[pipelines][1],1);
            }

            for(int i=0;i<convert_times;i++){
                close(fd[i][0]);
                close(fd[i][1]);
            }
            if(orig_type==new_type)
                execvp(argv[0],argv);
            else{
                execvp(convert[pipelines].convert_program[0],convert[pipelines].convert_program);
            }

        }else{
        }
        pipelines++;

    }
    for(int i=0;i<convert_times;i++){
        close(fd[i][0]);
        close(fd[i][1]);
    }

    for(int i=0;i<convert_times;i++){
        childs=waitpid(child_pid[i],&status,WNOHANG|WUNTRACED|WCONTINUED);
        if(childs<0)
            perror("wait error!");
        if(!WIFEXITED(status)){
            change_status(getpgid(getpid()),ABORTED);
            exit(EXIT_FAILURE);
        }else if(WIFSIGNALED(status)){
            change_status(getpgid(getpid()),ABORTED);
            exit(EXIT_FAILURE);
        }else if(WIFSTOPPED(status)){
            change_status(getpgid(getpid()),PAUSED);
        }else if(WIFCONTINUED(status)){
            change_status(getpgid(getpid()),RUNNING);
        }
        if(i==convert_times-1){
            exit(EXIT_SUCCESS);
        }
    }

     //exit(status);


}

int check_real_program(CONVERT this_convert){
    if(this_convert.convert_program!=NULL)
        return 1;
    else
        return -1;
}
int find_convert(int old_type, int new_type){
    int convert_id=-1;
    for(int i=0;i<num_conversion;i++){
        if(old_type==convert_list[i].old_type_ID && new_type==convert_list[i].new_type_ID){
            convert_id=i;
            break;
        }
    }
    return convert_id;
}

CONVERT* find_convert_order(int convert_num, int old_type, int new_type){
    int old=old_type;
    int new=new_type;
    int convert_id;

    CONVERT* convert_order=malloc(sizeof(CONVERT)*convert_num);
    CONVERT this_convert;


    convert_id=find_convert(old,new);
    this_convert=convert_list[convert_id];

    if(convert_num==1){
        convert_order[0]=this_convert;
        return convert_order;
    }
    else{
        for(int i=convert_num-1;i>-1;i--){
            convert_order[i]=*this_convert.next_convert;
            this_convert=*this_convert.prev_convert;
            if(check_real_program(this_convert)==1){
                i--;
                convert_order[i]=this_convert;
            }

        }
    }

    return convert_order;

}




