#ifndef TYPE_COVERT_H
#define TYPE_COVERT_H

#include <stdint.h>
#include <stdlib.h>
#include "imprimer.h"
#include "helper.h"


struct convert {
    int old_type_ID;
    int new_type_ID;
    char** convert_program;//char** convert_program
    struct convert* prev_convert;
    struct convert* next_convert;
};

typedef struct convert CONVERT;

CONVERT convert_list[64*63];
int convert_matrix[MAX_TYPES][MAX_TYPES]={0,};


#endif
