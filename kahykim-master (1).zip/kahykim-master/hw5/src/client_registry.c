#include "csapp.h"
#include "client_registry.h"
#include "debug.h"


struct client_registry{
    int file_d[1024];
    int count;
    pthread_mutex_t lock;
    sem_t empty;
};

//Initalize the client registry
CLIENT_REGISTRY *creg_init(){
    CLIENT_REGISTRY *client_registry;
    client_registry=malloc(sizeof(CLIENT_REGISTRY));
    for(int i=0;i<1024;i++)
        client_registry->file_d[i]=-1;
    client_registry->count=0;
    if(pthread_mutex_init(&client_registry->lock,NULL)!=0){
        perror("mutex fails\n");//test
    }
    Sem_init(&client_registry->empty,0,0);//test
    debug("Initialize client registry");
    return client_registry;
}

//finalize the client registry
void creg_fini(CLIENT_REGISTRY *cr){
    Free(cr);
    debug("Finalize client registry");
}
/*
 * Register a client file descriptor.
 *
 * @param cr  The client registry.
 * @param fd  The file descriptor to be registered.
 */
void creg_register(CLIENT_REGISTRY *cr, int fd){
    pthread_mutex_lock(&cr->lock);
    for(int i=0;i<1024;i++){
        if(cr->file_d[i] < 0){
            cr->file_d[i]=fd;
            cr->count++;
            break;
        }
    }
    debug("Register client %d (total connected : %d)",fd,cr->count);
    pthread_mutex_unlock(&cr->lock);
}
/*
 * Unregister a client file descriptor, alerting anybody waiting
 * for the registered set to become empty.
 *
 * @param cr  The client registry.
 * @param fd  The file descriptor to be unregistered.
 */
void creg_unregister(CLIENT_REGISTRY *cr, int fd){
    pthread_mutex_lock(&cr->lock);
    if(cr->count!=0){
        for(int i=0;i<1024;i++){
            if(cr->file_d[i]==fd){
                cr->file_d[i]=-1;
                cr->count--;
                break;
            }
        }
    }
    if(cr->count==0){
        V(&cr->empty);
    }
    debug("Unregister client %d (total connected : %d)",fd,cr->count);
    pthread_mutex_unlock(&cr->lock);

}
/*
 * A thread calling this function will block in the call until
 * the number of registered clients has reached zero, at which
 * point the function will return.
 *
 * @param cr  The client registry.
 */

void creg_wait_for_empty(CLIENT_REGISTRY *cr){
    P(&cr->empty);
}

/*
 * Shut down all the currently registered client file descriptors.
 *
 * @param cr  The client registry.
 */
void creg_shutdown_all(CLIENT_REGISTRY *cr){
    pthread_mutex_lock(&cr->lock);
    for(int i=0;i<cr->count;i++){
        shutdown(cr->file_d[i],SHUT_RDWR);
        Close(cr->file_d[i]);
        cr->file_d[i]=-1;
    }
    cr->count=0;
    pthread_mutex_unlock(&cr->lock);
}
