#include "transaction.h"
#include "csapp.h"
#include "debug.h"


/*
 * For debugging purposes, all transactions having a nonzero reference count
 * are maintained in a circular, doubly linked list which has the following
 * sentinel as its head.
 */

int trans_id;

/*
 * Initialize the transaction manager.
 */
void trans_init(void){
    debug("Initialize transaction manager");
    trans_id=0;
    trans_list.next=&trans_list;
    trans_list.prev=&trans_list;
}

/*
 * Finalize the transaction manager.
 */
void trans_fini(void){
    debug("Finalize transaction manager");
    TRANSACTION *trans_next;
    TRANSACTION *this;
    trans_next=trans_list.next;
    while(1){
        if(trans_next==&trans_list){
            break;
        }
        if(trans_next->status==TRANS_ABORTED || trans_next->status==TRANS_COMMITTED)
            break;
        if(trans_next->status==TRANS_PENDING){
            this=trans_next;
            trans_next->next->prev=trans_next->prev;
            trans_next->prev->next=trans_next;
            trans_next=trans_next->next;
            Free(this);
        }
    }
    trans_list.next=&trans_list;
    trans_list.prev=&trans_list;
}

/*
 * Create a new transaction.
 *
 * @return  A pointer to the new transaction (with reference count 1)
 * is returned if creation is successful, otherwise NULL is returned.
 */
TRANSACTION *trans_create(void){
    TRANSACTION *trans=Malloc(sizeof(TRANSACTION));//test sizeof(TRANSACTION)
    trans->refcnt=0;
    trans->id=trans_id;
    trans_id++;
    trans->status=TRANS_PENDING;
    trans->depends=NULL;
    trans->waitcnt=0;
    Sem_init(&trans->sem,0,0);
    debug("Create new transaction %d",trans->id);
    if(pthread_mutex_init(&trans->mutex,NULL)!=0){
        perror("mutex fails\n");//test
    }
    if(trans_list.next==&trans_list && trans_list.prev==&trans_list){
        trans_list.next=trans;
        trans_list.prev=trans;
        trans->next=&trans_list;
        trans->prev=&trans_list;
    }else{
        TRANSACTION *tmp_trans;
        tmp_trans=trans_list.next;
        while(1){
            if(tmp_trans->next==&trans_list){
                tmp_trans->next=trans;
                trans->next=&trans_list;
                trans->prev=tmp_trans;
                break;
            }
            tmp_trans=tmp_trans->next;
        }

    }
    trans_ref(trans,"for newly created transaction");
    return trans;
}

/*
 * Increase the reference count on a transaction.
 *
 * @param tp  The transaction.
 * @param why  Short phrase explaining the purpose of the increase.
 * @return  The transaction pointer passed as the argument.
 */
TRANSACTION *trans_ref(TRANSACTION *tp, char *why){
    pthread_mutex_lock(&tp->mutex);
    debug("Increase ref count on transaction %d (%d->%d) %s",tp->id,tp->refcnt,tp->refcnt+1,why);
    tp->refcnt++;
    pthread_mutex_unlock(&tp->mutex);
    return tp;
}

/*
 * Decrease the reference count on a transaction.
 * If the reference count reaches zero, the transaction is freed.
 *
 * @param tp  The transaction.
 * @param why  Short phrase explaining the purpose of the decrease.
 */
void trans_unref(TRANSACTION *tp, char *why){
    pthread_mutex_lock(&tp->mutex);
    debug("Decrease ref count on transaction %d (%d->%d) %s",tp->id,tp->refcnt,tp->refcnt-1,why);
    if(tp->refcnt==0)
        return;
    tp->refcnt--;
    pthread_mutex_unlock(&tp->mutex);
    if(tp->refcnt==0){
        debug("Free transaction %d",tp->id);
        if(tp->depends!=NULL){
            DEPENDENCY *dep=tp->depends;
            while(1){
                if(dep==NULL){
                    Free(tp->depends);
                    break;
                }
                trans_unref(dep->trans,"as transaction in dependency");
                dep=dep->next;
            }
        }
        TRANSACTION* next=tp->next;
        TRANSACTION* prev=tp->prev;
        prev->next=next;
        next->prev=prev;
        Free(tp);
    }

}

/*
 * Add a transaction to the dependency set for this transaction.
 *
 * @param tp  The transaction to which the dependency is being added.
 * @param dtp  The transaction that is being added to the dependency set.
 */
void trans_add_dependency(TRANSACTION *tp, TRANSACTION *dtp){
    debug("Make transaction %d dependent on transaction %d",tp->id,dtp->id);

    DEPENDENCY* dep=Malloc(sizeof(DEPENDENCY));
    dep->trans=dtp;
    dep->next=NULL;
    if(tp->depends==NULL){
        tp->depends=dep;
        trans_ref(dtp,"for transaction in dependency");
    }
    else{
        dep->next=tp->depends;
        tp->depends=dep;
        debug("first depends : %d",tp->depends->trans->id);//test
        debug("second depends : %d",tp->depends->next->trans->id);//test
        trans_ref(dtp,"for transaction in dependency");
    }
}

TRANS_STATUS wait_for_dependency(TRANSACTION *tp, TRANSACTION* dtp){
    debug("Transaction %d checking status of dependency %d",tp->id,dtp->id);
    if(trans_get_status(dtp)==TRANS_ABORTED){
        trans_abort(tp);
        return TRANS_ABORTED;
    }
    if(trans_get_status(dtp)==TRANS_COMMITTED){
        debug("Transaction %d already commited",dtp->id);
        return TRANS_COMMITTED;
    }
    debug("Transaction %d waiting for dependency %d",tp->id,dtp->id);
    pthread_mutex_lock(&dtp->mutex);
    dtp->waitcnt++;
    pthread_mutex_unlock(&dtp->mutex);
    P(&dtp->sem);
    return TRANS_COMMITTED;

}

/*
 * Try to commit a transaction.  Committing a transaction requires waiting
 * for all transactions in its dependency set to either commit or abort.
 * If any transaction in the dependency set abort, then the dependent
 * transaction must also abort.  If all transactions in the dependency set
 * commit, then the dependent transaction may also commit.
 *
 * In all cases, this function consumes a single reference to the transaction
 * object.
 *
 * @param tp  The transaction to be committed.
 * @return  The final status of the transaction: either TRANS_ABORTED,
 * or TRANS_COMMITTED.
 */
TRANS_STATUS trans_commit(TRANSACTION *tp){
    debug("transaction %d trying to commit",tp->id);
    if(tp->depends!=NULL){
        DEPENDENCY* tmp=tp->depends;
        while(1){
            if(tmp==NULL)
                break;
            if(wait_for_dependency(tp,tmp->trans)==TRANS_ABORTED)
                return TRANS_ABORTED;
            //debug("Release %d waiters depend on transaction %d",tp->waitcnt,tmp->trans->id);
            debug("Transaction %d finished waiting for dependency %d",tp->id,tmp->trans->id);//test
            tmp=tmp->next;
        }
    }
    debug("Transaction %d commits",tp->id);
    debug("Release %d waiters dependent on transaction %d",tp->waitcnt,tp->id);//test
    pthread_mutex_lock(&tp->mutex);
    while(tp->waitcnt!=0){
         V(&tp->sem);
         tp->waitcnt--;
    }
    pthread_mutex_unlock(&tp->mutex);

    pthread_mutex_lock(&tp->mutex);//add
    tp->status=TRANS_COMMITTED;
    pthread_mutex_unlock(&tp->mutex);//add
    trans_unref(tp,"for committing transaction");
    return TRANS_COMMITTED;
}

/*
 * Abort a transaction.  If the transaction has already committed, it is
 * a fatal error and the program crashes.  If the transaction has already
 * aborted, no change is made to its state.  If the transaction is pending,
 * then it is set to the aborted state, and any transactions dependent on
 * this transaction must also abort.
 *
 * In all cases, this function consumes a single reference to the transaction
 * object.
 *
 * @param tp  The transaction to be aborted.
 * @return  TRANS_ABORTED.
 */
TRANS_STATUS trans_abort(TRANSACTION *tp){
    debug("Try to abort transaction %d",tp->id);
    V(&tp->sem);
    pthread_mutex_lock(&tp->mutex);
    tp->status=TRANS_ABORTED;
    pthread_mutex_unlock(&tp->mutex);
    debug("Transaction %d has aborted",tp->id);
    trans_unref(tp,"for aborting transaction");
    //Free(tp);
    return TRANS_ABORTED;

}
/*
 * Get the current status of a transaction.
 * If the value returned is TRANS_PENDING, then we learn nothing,
 * because unless we are holding the transaction mutex the transaction
 * could be aborted at any time.  However, if the value returned is
 * either TRANS_COMMITTED or TRANS_ABORTED, then that value is the
 * stable final status of the transaction.
 *
 * @param tp  The transaction.
 * @return  The status of the transaction, as it was at the time of call.
 */
TRANS_STATUS trans_get_status(TRANSACTION *tp){
    return tp->status;
}
/*
 * Print information about a transaction to stderr.
 * No locking is performed, so this is not thread-safe.
 * This should only be used for debugging.
 *
 * @param tp  The transaction to be shown.
 */
void trans_show(TRANSACTION *tp){
    fprintf(stderr,"[id=%d, status = %d, refcnt=%d]",
                    tp->id, tp->status,tp->refcnt);
}

/*
 * Print information about all transactions to stderr.
 * No locking is performed, so this is not thread-safe.
 * This should only be used for debugging.
 */
void trans_show_all(void){
    if(trans_list.next==&trans_list)
        return;
    TRANSACTION *trans;
    trans=trans_list.next;
    while(1){
        trans_show(trans);
        trans=trans->next;
        if(trans==&trans_list)
            break;
    }
    fprintf(stderr,"\n");
}