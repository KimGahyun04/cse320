/**
 * All functions you make for the assignment must be implemented in this file.
 * Do not submit your assignment with a main function in this file.
 * If you submit with a main function in this file, you will get a zero.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "debug.h"
#include "sfmm.h"
#include <errno.h>
#include "global.h"

#define WSIZE           sizeof(Word) /*word size 2 bytes(16bits)*/
#define DSIZE           sizeof(Double_Word) /*Double word size, 4byites(32bits)*/
#define QSIZE           sizeof(Quad_Word) /*4 word size, header size*/
#define ARSIZE          16
#define MIN_REQ_SIZE    24
#define MIN_BLOCK_SIZE  32


sf_block_info make_header_info(unsigned rq_size,unsigned size,unsigned prev_alloc,unsigned alloc){

    sf_block_info myinfo;
    myinfo.allocated=alloc;
    myinfo.prev_allocated=prev_alloc;
    myinfo.two_zeroes=0;
    myinfo.block_size=size>>4;
    myinfo.requested_size=rq_size;

    return myinfo;
}

void coelescing(sf_header* free_head, sf_footer* free_foot){

    size_t block_size;
    sf_header* next_free_block_header=(sf_header*)((Block_ptr)free_foot+QSIZE);
    block_size=free_head->info.block_size << 4;
    unsigned prev_alloc=free_head->info.prev_allocated;
    unsigned next_alloc=next_free_block_header->info.allocated;

    if(prev_alloc && next_alloc){
        insert_free_node(block_size,free_head);
    }
    else if(prev_alloc && !next_alloc){
        delete_from_free_list(next_free_block_header);
        size_t next_block_size=next_free_block_header->info.block_size << 4;
        sf_footer* next_free_block_footer=(sf_footer*)((Block_ptr)next_free_block_header+next_block_size-QSIZE);
        free_head->info.block_size=(next_block_size+block_size)>>4;
        next_free_block_footer->info.block_size=(next_block_size+block_size)>>4;
        next_free_block_footer->info.prev_allocated=free_head->info.prev_allocated;
        insert_free_node(block_size+next_block_size,free_head);
    }
    else if(!prev_alloc && next_alloc){
        sf_footer* prev_free_block_footer=(sf_footer*)((Block_ptr)free_head-QSIZE);
        size_t prev_block_size=prev_free_block_footer->info.block_size << 4;
        sf_header* prev_free_block_header=(sf_header*)((Block_ptr)prev_free_block_footer-prev_block_size+QSIZE);
        delete_from_free_list(prev_free_block_header);
        prev_free_block_header->info.block_size=(prev_block_size+block_size)>>4;
        free_foot->info.block_size=(prev_block_size+block_size)>>4;
        free_foot->info.prev_allocated=prev_free_block_header->info.prev_allocated;
        insert_free_node(prev_block_size+block_size,prev_free_block_header);
    }
    else{
        delete_from_free_list(next_free_block_header);
        sf_footer* prev_free_block_footer=(sf_footer*)((Block_ptr)free_head-QSIZE);
        size_t prev_block_size=prev_free_block_footer->info.block_size << 4;
        sf_header* prev_free_block_header=(sf_header*)((Block_ptr)prev_free_block_footer-prev_block_size+QSIZE);
        delete_from_free_list(prev_free_block_header);
        size_t next_block_size=next_free_block_header->info.block_size << 4;
        sf_footer* next_free_block_footer=(sf_footer*)((Block_ptr)next_free_block_header+next_block_size-QSIZE);
        prev_free_block_header->info.block_size=(next_block_size+prev_block_size+block_size) >> 4;
        next_free_block_footer->info.block_size=(next_block_size+prev_block_size+block_size) >> 4;
        next_free_block_footer->info.prev_allocated=prev_free_block_header->info.prev_allocated;
        insert_free_node((next_block_size+prev_block_size+block_size),prev_free_block_header);
   }
}


void delete_from_free_list(sf_header* delete){

    sf_header* prev_delete=delete->links.prev;
    sf_header* next_delete=delete->links.next;
    prev_delete->links.next=next_delete;
    next_delete->links.prev=prev_delete;
    delete->links.next=NULL;
    delete->links.prev=NULL;

}


void insert_free_block(sf_header* head,sf_header* new){
    /*
    *If free block list is empty
    */
    if((head->links.next==head) && (head->links.prev==head)){
        head->links.next=new;
        head->links.prev=new;
        new->links.prev=head;
        new->links.next=head;
    }
    /*
    *If free block list is not empty
    */
    else{
        new->links.prev=head;
        new->links.next=head->links.next;
        head->links.next=new;
        (head->links.next)->links.prev=new;
    }

}


sf_header* find_free_block(size_t size){
    sf_free_list_node *current;
    sf_header* current_head;


    current=sf_free_list_head.next;
    current_head=&(current->head);
    while(1){
        /*if find the block that is fitted */
        if((current->size == size) || (current->size > size)){
            /*
            *If there are size but there's no free block in that size of list return NULL
            */

            if((current_head->links.next==current_head) && (current_head->links.prev==current_head))
                return NULL;

            size_t diff=current->size-size; // to check the free block can split or not

            /*
            *delete the free block header from the free list
            */
            sf_header* free_block_head;
            sf_header* prev_free_block_head;
            sf_header* next_free_block_head;

            free_block_head=current_head->links.next;
            prev_free_block_head=current_head;
            next_free_block_head=free_block_head->links.next;


            prev_free_block_head->links.next=next_free_block_head;
            next_free_block_head->links.prev=prev_free_block_head;

            /*
            *If free block size-request block size is bigger than minimum block size,
            *spliting the block and insert the new free block to the free list.
            */
            if((diff == MIN_BLOCK_SIZE) || (diff > MIN_BLOCK_SIZE)){
                sf_header* split_block_head;
                sf_footer* split_block_foot;

                split_block_head=(sf_header*)((Block_ptr)free_block_head+size);
                split_block_head->info=make_header_info(0,diff,1,0);
                split_block_head->links.next=NULL;
                split_block_head->links.prev=NULL;
                split_block_foot=(sf_footer*)((Block_ptr)free_block_head+(current->size-QSIZE));
                split_block_foot->info=make_header_info(0,diff,1,0);
                insert_free_node(diff,split_block_head);

            }
            return free_block_head;
        }
        if(size > current->size && current->next==&(sf_free_list_head)){
            return NULL;
        }
        current=current->next;
    }
}


void insert_free_node(size_t size,sf_header* new){


    sf_free_list_node *head_free_list;
    sf_free_list_node *current;
    /*when the list of free list is empty*/
    if((sf_free_list_head.next == &sf_free_list_head) && (sf_free_list_head.prev == &sf_free_list_head)){
        if((head_free_list=sf_add_free_list(size,&sf_free_list_head))!=NULL){
            head_free_list->head.links.next=&(head_free_list->head);
            head_free_list->head.links.prev=&(head_free_list->head);
        }
    }
    current=sf_free_list_head.next;
    while(1){
        /*if the size of free block is not in the */
        if(size < current->size){
            sf_free_list_node *prev_current_node;
            if((prev_current_node=sf_add_free_list(size,current))!=NULL){
                prev_current_node->head.links.next=&(prev_current_node->head);
                prev_current_node->head.links.prev=&(prev_current_node->head);
            }
            insert_free_block(&(prev_current_node->head),new);
            break;
        }
        /*if the exact size of free block is in the list*/
        else if(size==current->size){
            insert_free_block(&(current->head),new);
            break;
        }
        /*if the size of free block is bigger than the max size of free block in list*/
        else if(size > current->size && current->next==&sf_free_list_head){
            sf_free_list_node *next_current_node;
            if((next_current_node=sf_add_free_list(size,current->prev))!=NULL){
                next_current_node->head.links.next=&(next_current_node->head);
                next_current_node->head.links.prev=&(next_current_node->head);
            }
            insert_free_block(&(next_current_node->head),new);
            break;
        }
        current=current->next;

    }
}



void *sf_malloc(size_t size) {

    size_t asize;
    Block_ptr *heap_start;
    sf_header *alloc_block;
    sf_prologue *my_prologue;
    sf_epilogue *my_epilogue;
    if(size > 4*PAGE_SZ){
        sf_errno=ENOMEM;
        return NULL;
    }

    /*
    *return If size is 0,then NULL is returned without setting sf_errno.
    */

    if (size == 0)
        return NULL;

    /*
    *If size is nonzero, then if the allocation is successful
    *a pointer to a valid region of memory of the requested size is returned.
    */

    if(size<=MIN_REQ_SIZE)
        asize=QSIZE*2+ARSIZE;
    else{
        if((size+QSIZE)%ARSIZE==0)
            asize=size+QSIZE;
        else
            asize=((size+QSIZE+ARSIZE)/ARSIZE)*ARSIZE; //round up to the nearest multiple of 16
    }

    if(sf_mem_start()==sf_mem_end()){
        if((heap_start=sf_mem_grow())!=NULL){
            sf_header *free_block_header;
            sf_footer *free_block_footer;
            my_prologue=sf_mem_start();
            my_prologue->padding=0;
            my_prologue->header.info=make_header_info(0,0,0,1);
            my_prologue->header.payload=0;
            my_prologue->footer.info=make_header_info(0,0,0,1);
            free_block_header=sf_mem_start()+sizeof(*my_prologue);
            free_block_header->info=make_header_info(0,PAGE_SZ-sizeof(*my_prologue)-QSIZE,1,0);
            free_block_header->links.prev=NULL;
            free_block_header->links.next=NULL;
            free_block_footer=sf_mem_end()-QSIZE*2;
            free_block_footer->info=make_header_info(0,PAGE_SZ-sizeof(*my_prologue)-QSIZE,1,0);
            my_epilogue=sf_mem_end()-QSIZE;
            my_epilogue->footer.info=make_header_info(0,0,0,1);
            insert_free_node(PAGE_SZ-sizeof(*my_prologue)-QSIZE,free_block_header);


        }
        else{
            /*
            *If th allocation is not sucessful, then Null is rturned and sf_errono is set to ENOMEM.
            */
            sf_errno=ENOMEM;
            return NULL;
        }
    }

    while(1){
        if((alloc_block=find_free_block(asize))!=NULL){
            size_t alloc_size=alloc_block->info.block_size << 4;
            if((alloc_size - asize) > MIN_BLOCK_SIZE || (alloc_size - asize) ==MIN_BLOCK_SIZE){
                alloc_block->info.block_size=asize >> 4;
            }
            alloc_block->info.requested_size=size;
            alloc_block->info.allocated=1;

            return &(alloc_block->payload);
        }else{
             if((heap_start=sf_mem_grow())!=NULL){
                sf_header *new_free_block_header;
                sf_footer *new_free_block_footer;
                new_free_block_header=(sf_header*)((Block_ptr)heap_start-QSIZE);
                new_free_block_header->info=make_header_info(0,PAGE_SZ,my_epilogue->footer.info.prev_allocated,0);
                new_free_block_footer=sf_mem_end()-2*QSIZE;
                new_free_block_footer->info=make_header_info(0,PAGE_SZ,my_epilogue->footer.info.prev_allocated,0);
                my_epilogue=sf_mem_end()-QSIZE;
                my_epilogue->footer.info=make_header_info(0,0,0,1);
                coelescing(new_free_block_header,new_free_block_footer);

            }
            else{
                sf_errno=ENOMEM;
                return NULL;
            }
        }

    }


    return &(alloc_block->payload);




}

void verify_pointer(void* pp){
    size_t size;
    unsigned prev_alloc;
    size_t prev_block_size;
    sf_footer* prev_block_footer;
    sf_header* prev_block_header;
    sf_header* block_head=(sf_header*)((Block_ptr)pp-QSIZE);
    Block_ptr end_of_prologue;
    Block_ptr beginning_of_epilogue;
    /*The pointer is NULL*/
    if(pp==NULL){
        abort();
    }

    /*The header of the block is before the end of the prologue, or after the beginning of the epilogue*/
    end_of_prologue=(Block_ptr)sf_mem_start()+sizeof(sf_prologue);
    beginning_of_epilogue=(Block_ptr)sf_mem_end()-sizeof(sf_epilogue);
    if((end_of_prologue-(Block_ptr)block_head) > 0)
        abort();

    if(((Block_ptr)block_head - beginning_of_epilogue) > 0)
        abort();


    /*The allocated bit in the header or footer is 0*/
    if(block_head->info.allocated==0){
        abort();
    }
    size=block_head->info.block_size << 4;

    /*THe block_size fields is not a multiple of 16 or is less than the minimum block size of 32 bytes*/
    if((size < MIN_BLOCK_SIZE) || (size % 16 != 0)){
        abort();
    }

    /*The requested_size field, plus the size required for the block header is greater than the block_size field*/
    if(QSIZE+block_head->info.requested_size>size){
        abort();
    }
    /*If the prev_alloc field is 0, inidicating that the previous block is free,
    *Then the alloc fields of the previous block header and footer should also be 0
    */
    prev_alloc=block_head->info.prev_allocated;
    if(prev_alloc==0){
        prev_block_footer=(sf_footer*)((Block_ptr)block_head-QSIZE);
        prev_block_size=prev_block_footer->info.block_size << 4;
        prev_block_header=(sf_header*)((Block_ptr)block_head+prev_block_size);
        if((prev_block_footer->info.allocated == 1) || (prev_block_header->info.allocated==1)){
            abort();
        }
    }
}

void sf_free(void *pp) {

    sf_header* next_block_header;
    sf_header* free_head;
    sf_footer* free_foot;
    size_t size;

    unsigned prev_alloc;
    verify_pointer(pp);

    sf_header* block_head=(sf_header*)((Block_ptr)pp-QSIZE);
    size=block_head->info.block_size << 4;
    prev_alloc=block_head->info.prev_allocated;

    free_head=block_head;
    free_head->info=make_header_info(0,size,prev_alloc,0);

    free_foot=(sf_footer*)((Block_ptr)block_head+size-QSIZE);
    free_foot->info=free_head->info;
    next_block_header=(sf_header*)((Block_ptr)free_foot+QSIZE);
    next_block_header->info.prev_allocated=0;

    coelescing(free_head,free_foot);

    return;
}

void *sf_realloc(void *pp, size_t rsize) {
    verify_pointer(pp);
    Block_ptr new_pay_load;
    sf_header* block_head=(sf_header*)((Block_ptr)pp-QSIZE);
    sf_footer* block_footer;
    size_t old_block_size=block_head->info.block_size << 4;
    block_footer=(sf_footer*)((Block_ptr)block_head+old_block_size-QSIZE);
    size_t new_block_size;


    if(rsize<=MIN_REQ_SIZE)
        new_block_size=QSIZE*2+ARSIZE;
    else{
        if((rsize+QSIZE)%ARSIZE==0)
            new_block_size=rsize+QSIZE;
        else
            new_block_size=((rsize+QSIZE+ARSIZE)/ARSIZE)*ARSIZE; //round up to the nearest multiple of 16
    }

    if(rsize==0){
        sf_free(pp);
        return NULL;
    }

    if(rsize>old_block_size){
        if((new_pay_load=(Block_ptr)sf_malloc(rsize))!=NULL){
            memcpy(new_pay_load,pp,rsize);
            sf_free(pp);


            return new_pay_load;
        }
        else
            return NULL;

    }
    else {
        if(old_block_size-new_block_size<MIN_BLOCK_SIZE){
            block_head->info.requested_size=rsize;
            block_footer->info.requested_size=rsize;
        }
        else{
            block_head->info.requested_size=rsize;
            block_head->info.block_size=new_block_size >> 4;
            block_footer->info.requested_size=rsize;
            block_footer->info.block_size=new_block_size >> 4;
            split_block(block_head,old_block_size,new_block_size);


        }

        return &(block_head->payload);
    }

}
void split_block(sf_header* block_head, size_t old_block_size, size_t new_block_size){

    sf_header* new_free_block_header;
    sf_footer* new_free_block_footer;

    sf_header* next_new_free_block_header;
    sf_footer* next_new_free_block_footer;
    size_t next_block_size;

    new_free_block_header=(sf_header*)((Block_ptr)block_head+new_block_size);
    new_free_block_header->info=make_header_info(0,old_block_size-new_block_size,1,0);
    new_free_block_footer=(sf_footer*)((Block_ptr)new_free_block_header+old_block_size-new_block_size-QSIZE);
    new_free_block_footer->info=new_free_block_header->info;
    next_new_free_block_header=(sf_header*)((Block_ptr)new_free_block_footer+QSIZE);
    next_block_size=next_new_free_block_header->info.block_size<<4;
    next_new_free_block_footer=(sf_footer*)((Block_ptr)next_new_free_block_header+next_block_size-QSIZE);
    next_new_free_block_footer->info.prev_allocated=0;
    next_new_free_block_header->info.prev_allocated=0;
    coelescing(new_free_block_header,new_free_block_footer);

}

