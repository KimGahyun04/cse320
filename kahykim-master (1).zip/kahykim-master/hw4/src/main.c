#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <getopt.h>
#include <readline/readline.h>
#include <readline/history.h>
#include "imprimer.h"
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include "helper.h"
#include "job_handler.h"


#define COMMAND_NUMBER (12)

/*
 * "Imprimer" printer spooler.
 */



typedef enum { HELP=1, QUIT, TYPE, CONVERSION, PRINTER_CMD, PRINTERS,JOBS,PRINT,
              CANCEL,PAUSE, RESUME,DISABLE,ENABLE } COMMAND_LIST;

char* command[]={
    "help",
    "quit",
    "type",
    "conversion",
    "printer",
    "printers",
    "jobs",
    "print",
    "cancel",
    "pause",
    "resume",
    "disable",
    "enable"
};


void excute_cmd(char* cmd_line){
    int get_cmd_num=0;
    char* copy_cmd_line=strdup(cmd_line);
    int count=0;
    char* parse_cmd_line[100];//test;
    char* result=NULL;
    char* conversion_program_list[200];
    char* choosen_printerlist[MAX_PRINTERS];
    int num_chosen_printer=0;
    int convert_int=0;

    while((result=strsep(&copy_cmd_line," "))!=NULL){
        //parse_cmd_line[count]=malloc(sizeof(char)*(strlen(result)+1));
        if(strlen(result)!=0){
            parse_cmd_line[count]=result;
            //strcpy(parse_cmd_line[count],result);
            if(strcmp(parse_cmd_line[0],"print")==0){
                get_cmd_num=8;
                if(count > 1){
                    choosen_printerlist[num_chosen_printer]=parse_cmd_line[count];
                    //strcpy(choosen_printerlist[num_chosen_printer],parse_cmd_line[count]);
                    num_chosen_printer++;
                }
            }
            else if(strcmp(parse_cmd_line[0],"conversion")==0){
                get_cmd_num=4;
                if(count>2){
                    conversion_program_list[convert_int]=parse_cmd_line[count];
                    //strcpy(conversion_program_list[convert_int],parse_cmd_line[count]);
                    convert_int++;
                }

            }
            conversion_program_list[convert_int]=NULL;
            choosen_printerlist[num_chosen_printer]=NULL;
            if(count>10){
                imp_format_error_message("Invalid command\n",buf,sizeof(buf));
                return;
            }
            count++;
        }

    }
    free(copy_cmd_line);//test
    for(int i=0;i<COMMAND_NUMBER+1;i++){
        if(strcmp(command[i],parse_cmd_line[0])==0)
            get_cmd_num=i+1;
    }

    if(get_cmd_num==0){
        imp_format_error_message("Invalid command.\n",buf,sizeof(buf));
        return;
    }
    switch(get_cmd_num){
        case HELP:
        if(count > 1){
            imp_format_error_message("Too many arguments\n",buf,sizeof(buf));
            break;
        }
        cmd_help();
        break;
        if(count > 1){
            imp_format_error_message("Too many arguments\n",buf,sizeof(buf));
            break;
        }
        case QUIT:
        cmd_quit();
        break;
        case TYPE:
        if(count==1){
            imp_format_error_message("need an argument\n",buf,sizeof(buf));
            break;
        }
        if(count > 2){
            imp_format_error_message("Too many arguments\n",buf,sizeof(buf));
            break;
        }
        cmd_type(parse_cmd_line[1]);
        break;
        case CONVERSION:
        if(count==1){
            imp_format_error_message("need an argument\n",buf,sizeof(buf));
            break;
        }
        cmd_conversion(parse_cmd_line[1],parse_cmd_line[2],conversion_program_list,convert_int);
        break;
        case PRINTER_CMD:
        if(count < 3){
            imp_format_error_message("need an arguments\n",buf,sizeof(buf));
            break;
        }
        if(count > 3){
            imp_format_error_message("Too many arguments\n",buf,sizeof(buf));
            break;
        }
        cmd_printer(parse_cmd_line[1],parse_cmd_line[2]);

        break;
        case PRINTERS:
        if(count > 1){
            imp_format_error_message("Too many arguments\n",buf,sizeof(buf));
            break;
        }
        cmd_printers();
        break;
        case JOBS:
        if(count > 1){
            imp_format_error_message("Too many arguments\n",buf,sizeof(buf));
            break;
        }
        cmd_jobs();
        break;
        case PRINT:
        if(count == 1){
            imp_format_error_message("needs an argument\n",buf,sizeof(buf));
            break;
        }
        cmd_print(parse_cmd_line[1],num_chosen_printer,choosen_printerlist);
        break;
        case CANCEL:
        if(count==1){
            imp_format_error_message("needs an argument\n",buf,sizeof(buf));
            break;
        }
        if(count>2){
            imp_format_error_message("Too many arguments\n",buf,sizeof(buf));
            break;
        }
        if(atoi(parse_cmd_line[1]) == 0 && parse_cmd_line[1][0]!='0'){
            imp_format_error_message("not a a valid job id\n",buf,sizeof(buf));
            break;
        }
        cmd_cancel(atoi(parse_cmd_line[1]));
        break;
        case PAUSE:
        if(count==1){
            imp_format_error_message("needs an argument\n",buf,sizeof(buf));
            break;
        }
        if(count>2){
            imp_format_error_message("Too many arguments\n",buf,sizeof(buf));
            break;
        }
         if(atoi(parse_cmd_line[1]) == 0 && parse_cmd_line[1][0]!='0'){
            imp_format_error_message("not a a valid job id\n",buf,sizeof(buf));
            break;
        }
        cmd_pause(atoi(parse_cmd_line[1]));
        break;
        case RESUME:
        if(count==1){
            imp_format_error_message("needs an argument\n",buf,sizeof(buf));
            break;
        }
        if(count>2){
            imp_format_error_message("Too many arguments\n",buf,sizeof(buf));
            break;
        }
         if(atoi(parse_cmd_line[1]) == 0 && parse_cmd_line[1][0]!='0'){
            imp_format_error_message("not a a valid job id\n",buf,sizeof(buf));
            break;
        }
        cmd_resume(atoi(parse_cmd_line[1]));
        break;
        case DISABLE:
        if(count==1){
            imp_format_error_message("needs an argument\n",buf,sizeof(buf));
            break;
        }
        if(count>2){
            imp_format_error_message("Too many arguments\n",buf,sizeof(buf));
            break;
        }
        cmd_disable(parse_cmd_line[1]);
        break;
        case ENABLE:
        if(count==1){
            imp_format_error_message("needs an argument\n",buf,sizeof(buf));
            break;
        }
        if(count>2){
            imp_format_error_message("Too many arguments\n",buf,sizeof(buf));
            break;
        }
        cmd_enable(parse_cmd_line[1]);
        default:
        break;
    }

}


int main(int argc, char *argv[])
{
    char optval;
    char* cmd_buf;
    FILE* file_in=NULL;
    FILE* file_out=NULL;
    file_output=stdout;
    int batch_mode=0;
    //int save_stdout;
    num_types=0;
    imp_num_printers=0;
    num_conversion=0;
    num_jobs=0;
    job_id=0;
    job_list=calloc(sizeof(JOB*),2000);
    //job_list=malloc(sizeof(JOB*)*2000);//test


    while(optind < argc) {
	if((optval = getopt(argc, argv, "i:o:")) != -1) {
	    switch(optval) {
        case 'i':
        file_in=fopen(optarg,"r");
        if(file_in==NULL){
            fprintf(stderr, "%s file doesn't exists\n", optarg);
            exit(EXIT_FAILURE);
        }
        file_out=fopen("output.log","w");
        batch_mode=1;
        break;
        case 'o':
        file_output=fopen(optarg,"w");
        break;
	    case '?':
		fprintf(stderr, "Usage: %s [-i <cmd_file>] [-o <out_file>]\n", argv[0]);
		exit(EXIT_FAILURE);
		break;
	    default:
		break;
	    }
	}
    }

    while(1){
        if(batch_mode){
            rl_instream=file_in;
            rl_outstream=file_out;
        }
        cmd_buf=readline("imp>");
        if(cmd_buf==NULL){
            if(batch_mode){
                fclose(file_in);
                rl_instream=stdin;
                rl_outstream=stdout;
                fprintf(stdout,"\n");
                batch_mode=0;
            }else{
                fprintf(stdout,"\n");
                exit(EXIT_SUCCESS);
            }
        }else{
            if(strlen(cmd_buf)!=0){
                add_history(cmd_buf);
                excute_cmd(cmd_buf);
                fprintf(file_output,"%s",buf);
                //write(fd_out,buf,strlen(buf)+1);
                strcpy(buf,"");
                scan_jobs();
            }

        }
        free(cmd_buf);//test

    }

    exit(EXIT_SUCCESS);
}
