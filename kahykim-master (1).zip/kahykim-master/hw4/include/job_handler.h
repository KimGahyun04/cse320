#ifndef JOB_HANDLER_H
#define JOB_HANDLER_H

#include <stdint.h>
#include <stdlib.h>
#include "imprimer.h"


JOB** job_list;
int num_jobs;
int job_id;
void delete_job(int job_id);

#endif