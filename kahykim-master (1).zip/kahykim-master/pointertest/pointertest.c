#include <stdio.h>

void inc(int* x){
    int c=10;
    x=&c;
   
}
int main(){
    int a=3;
    int* ptr =&a;
    inc(ptr);
    printf("%d\n",a);
    return 0;
}
