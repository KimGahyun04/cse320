#ifndef HW_H
#define HW_H

#include "audio.h"
#include "const.h"
#include "myrand.h"

int stringToInt(char *string);

int stringCompare(char *string1, char *string2);

unsigned long stringToHex(char *string);

#endif
