#include "data.h"
#include "csapp.h"
#include "transaction.h"
#include "debug.h"
/*
 * Create a blob with given content and size.
 * The content is copied, rather than shared with the caller.
 * The returned blob has one reference, which becomes the caller's
 * responsibility.
 *
 * @param content  The content of the blob.
 * @param size  The size in bytes of the content.
 * @return  The new blob, which has reference count 1.
 */
BLOB *blob_create(char *content, size_t size){
    BLOB *blob=Malloc(sizeof(BLOB));
    blob->size=size;
    blob->content=malloc(size+1);
    //blob->content=malloc(strlen(content)+1);
    memcpy(blob->content,content,size);
    //strcpy(blob->content,content);
    blob->prefix=malloc(size+1);
    //blob->prefix=malloc(strlen(content)+1);
    memcpy(blob->prefix,content,size);
    //strcpy(blob->prefix,content);//test

    if(pthread_mutex_init(&blob->mutex,NULL)!=0){
        perror("mutex fails\n");//test
    }
    debug("create blob with content %p, size %d->%p",content,(int)size,blob);
    blob_ref(blob,"for newly created blob");



    return blob;
}

/*
 * Increase the reference count on a blob.
 *
 * @param bp  The blob.
 * @param why  Short phrase explaining the purpose of the increase.
 * @return  The blob pointer passed as the argument.
 */
BLOB *blob_ref(BLOB *bp, char *why){
    debug("Increase reference count on blob %p[%s] (%d->%d) %s",
        bp,bp->prefix,bp->refcnt,bp->refcnt+1,why);
    pthread_mutex_lock(&bp->mutex);
    bp->refcnt++;
    pthread_mutex_unlock(&bp->mutex);

    return bp;
}

/*
 * Decrease the reference count on a blob.
 * If the reference count reaches zero, the blob is freed.
 *
 * @param bp  The blob.
 * @param why  Short phrase explaining the purpose of the decrease.
 */
void blob_unref(BLOB *bp, char *why){
    if(bp==NULL)
        return;//test
    debug("Decrease reference on blob %p [%s] (%d->%d) %s",
        bp,bp->prefix,bp->refcnt,bp->refcnt-1,why);
    if(bp->refcnt==0){
        Free(bp);//test
        return;
    }else{
        pthread_mutex_lock(&bp->mutex);
        bp->refcnt--;
        pthread_mutex_unlock(&bp->mutex);
        if(bp->refcnt==0){
            debug("Free blob %p[%s]",bp,bp->prefix);
            Free(bp);
            return;
        }
    }

}
/*
 * Compare two blobs for equality of their content.
 *
 * @param bp1  The first blob.
 * @param bp2  The second blob.
 * @return 0 if the blobs have equal content, nonzero otherwise.
 */
int blob_compare(BLOB *bp1, BLOB *bp2){
    if(bp1->size==bp2->size){
        if(memcmp(bp1->content,bp2->content,bp1->size)==0)
            return 0;
        else
            return -1;
    }
    /*if(strcmp(bp1->content,bp2->content)==0){
        return 0;//same contents
    }*/
    else
        return -1;
}

/*
 * Hash function for hashing the content of a blob.
 *
 * @param bp  The blob.
 * @return  Hash of the blob.
 */
int blob_hash(BLOB *bp){
    size_t i = 0;
    uint32_t hash = 0;
      while (i != bp->size) {
        hash += bp->content[i++];
        hash += hash << 10;
        hash ^= hash >> 6;
      }
      hash += hash << 3;
      hash ^= hash >> 11;
      hash += hash << 15;

      return abs(hash);
}

/*
 * Create a key from a blob.
 * The key inherits the caller's reference to the blob.
 *
 * @param bp  The blob.
 * @return  the newly created key.
 */
KEY *key_create(BLOB *bp){
    KEY* key=Malloc(sizeof(KEY));
    key->hash=blob_hash(bp);
    key->blob=bp;
    debug("key hash: %d",key->hash);//test
    debug("create key from blob %p->%p[%s]",bp,key,bp->prefix);
    return key;
}

/*
 * Dispose of a key, decreasing the reference count of the contained blob.
 * A key must be disposed of only once and must not be referred to again
 * after it has been disposed.
 *
 * @param kp  The key.
 */
void key_dispose(KEY *kp){
    debug("Dispose of key %p[%s]",kp,kp->blob->prefix);
    blob_unref(kp->blob,"for blob in key");
    Free(kp);
}

/*
 * Compare two keys for equality.
 *
 * @param kp1  The first key.
 * @param kp2  The second key.
 * @return  0 if the keys are equal, otherwise nonzero.
 */
int key_compare(KEY *kp1, KEY *kp2){
    debug("key compare");
    if((kp1->hash == kp2->hash) && (blob_compare(kp1->blob,kp2->blob)==0))
        return 0;
    else
        return -1;
}
/*
 * Create a version of a blob for a specified creator transaction.
 * The version inherits the caller's reference to the blob.
 * The reference count of the creator transaction is increased to
 * account for the reference that is stored in the version.
 *
 * @param tp  The creator transaction.
 * @param bp  The blob.
 * @return  The newly created version.
 */
VERSION *version_create(TRANSACTION *tp, BLOB *bp){
    VERSION* new_version=Malloc(sizeof(VERSION));
    if(bp==NULL){
        debug("Create NULL Version for transaction %d->%p",tp->id,tp);

    }else{
        debug("Create Version of blob %p[%s] for transaction %d->%p",
           bp,bp->prefix,tp->id,tp);
    }
    new_version->creator=trans_ref(tp,"as creator of version");
    new_version->blob=bp;
    new_version->next=NULL;
    new_version->prev=NULL;
    return new_version;
}

/*
 * Dispose of a version, decreasing the reference count of the
 * creator transaction and contained blob.  A version must be
 * disposed of only once and must not be referred to again once
 * it has been disposed.
 *
 * @param vp  The version to be disposed.
 */
void version_dispose(VERSION *vp){
    debug("Dispose of version %p",vp);
    blob_unref(vp->blob,"for blob in version");
    trans_unref(vp->creator,"as creator of version");
    Free(vp);

}




