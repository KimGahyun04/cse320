#include <stdint.h>
#include <stdlib.h>
#include "job_handler.h"
#include <sys/time.h>
#include <stdio.h>

void delete_job(int jobid){
    int job_position;
    for(int i=0;i<num_jobs;i++){
        if(job_list[i]->jobid==jobid){
            job_position=i+1;
        }
    }
    for(int i=job_position-1;i<num_jobs-1;i++){
        job_list[i]=job_list[i+1];
    }

    num_jobs--;
}