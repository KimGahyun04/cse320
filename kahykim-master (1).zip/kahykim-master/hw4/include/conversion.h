#ifndef CONVERSION_H
#define CONVERSION_H

#include <stdint.h>
#include <stdlib.h>
#include "imprimer.h"

#define MAX_CONVERSION (100)

typedef struct convert_type {
    char* old_type; // original type
    char* new_type; // new type
} CONVERT_TYPE;

CONVERT_TYPE conversion_list[MAX_CONVERSION];
int num_convert_type;

#endif