
#include <stdlib.h>
#include <stdio.h>
#include "sfmm.h"

typedef char Byte;
typedef short Word;
typedef unsigned int Double_Word;
typedef unsigned long Quad_Word;
typedef char * Block_ptr;

void verify_pointer(void* pp);
void split_block(sf_header* block_head, size_t old_block_size, size_t new_block_size);
void* set_alloc(sf_header* alloc_block,sf_epilogue* my_epilogue,size_t asize,size_t rq_size);
void delete_from_free_list(sf_header* delete);
void coelescing(sf_header* free_head,sf_footer* free_foot);
sf_block_info make_header_info(unsigned rq_size,unsigned size,unsigned prev_alloc,unsigned alloc);
void insert_free_block(sf_header* head,sf_header* new);
sf_header* find_free_block(size_t size);
void insert_free_node(size_t size,sf_header* new);